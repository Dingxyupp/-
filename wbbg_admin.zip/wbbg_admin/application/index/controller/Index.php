<?php


namespace app\index\controller;


use app\model\BrushDiscussModel;
use app\model\DiscussModel;
use app\model\IndexShowModel;
use app\model\PaintBrushModel;
use app\model\PaintModel;
use app\model\ResponseModel;
use app\model\ShopCarModel;
use think\Controller;
use think\Db;
use think\Request;

class Index extends Controller
{
   function index(){
       $r=IndexShowModel::select();
       return view("pages/index",["data"=>$r,"msg"=>"查找成功!"]);
   }

    function serve(){
        return view("pages/serve");
    }

    function wallCheck(){
        return view("pages/wallcheck");
    }

    function shop(){
        return view("pages/shop");
    }

    function mallIn(){
        $data=PaintModel::where("state",1)->select();
        if(isset($data)){
             return view("pages/mall-in",["data"=>$data,"msg"=>"查找成功"]);
        }else{
            return view("pages/mall-in",["msg"=>"没有数据"]);
        }
    }

    function mallOut(){
        $data=PaintModel::where("state",2)->select();
        if(isset($data)){
            return view("pages/mall-out",["data"=>$data,"msg"=>"查找成功"]);
        }else{
            return view("pages/mall-out",["msg"=>"没有数据"]);
        }
    }

    function mallMu(){
        $data=PaintModel::where("state",3)->select();
        if(isset($data)){
            return view("pages/mall-mu",["data"=>$data,"msg"=>"查找成功"]);
        }else{
            return view("pages/mall-mu",["msg"=>"没有数据"]);
        }
    }

    function mallTu(){
        $data=PaintBrushModel::where("state",4)->select();
        if(isset($data)){
            return view("pages/mall-tu",["data"=>$data,"msg"=>"查找成功"]);
        }else{
            return view("pages/mall-tu",["msg"=>"没有数据"]);
        }
    }

    function paintCalculation(){
        return view("pages/paintcalculation");
    }

    function aboutBrand(){
        return view("pages/aboutbrand");
    }

    function shopCar(){
       return view("pages/shop-car");

    }

    function personalCenter(){
        $userid=session("userid");
        $data=ResponseModel::where("id",$userid)->find();
        $this->assign(["data"=>$data]);
        return view("pages/personal-center");
    }

    function login(){
        return view("pages/login");
    }

    function register(){
        return view("pages/register");
    }

    function content(){
        return view("pages/content");
    }

    function goodsDetail($id){
       $data=PaintModel::where("id",$id)->select();
       $res=DiscussModel::where("goodsid",$id)->select();
       $good_res=DiscussModel::where("goodsid",$id)->where("state",1)->select();
       $middle_res=DiscussModel::where("goodsid",$id)->where("state",2)->select();
       $bad_res=DiscussModel::where("goodsid",$id)->where("state",3)->select();
       $this->assign("res",$res);
       $this->assign("good_res",$good_res);
       $this->assign("middle_res",$middle_res);
       $this->assign("bad_res",$bad_res);
       if($data){
           return view("pages/goods-detail",["data"=>$data,"msg"=>"查找成功"]);
       }
    }

    function brushDetail($id){
        $data=PaintBrushModel::where("id",$id)->select();
        $res=BrushDiscussModel::where("goodsid",$id)->select();
        $good_res=BrushDiscussModel::where("goodsid",$id)->where("state",1)->select();
        $middle_res=BrushDiscussModel::where("goodsid",$id)->where("state",2)->select();
        $bad_res=BrushDiscussModel::where("goodsid",$id)->where("state",3)->select();
        $this->assign("res",$res);
        $this->assign("good_res",$good_res);
        $this->assign("middle_res",$middle_res);
        $this->assign("bad_res",$bad_res);
        if($data){
            return view("pages/brush-detail",["data"=>$data,"msg"=>"查找成功"]);
        }
    }

    function logMange(){
        return view("pages/logmange");
    }

    function order(){
        return view("pages/order");
    }

    function pay(){
        return view("pages/pay");
    }

    function toAppraise(){
        return view("pages/toappraise");
    }

    function delask(){
        return view("pages/delask");
    }
}