<?php


namespace app\model;

use think\Model;
class LbtModel extends Model
{
    protected $table="lbt";
}