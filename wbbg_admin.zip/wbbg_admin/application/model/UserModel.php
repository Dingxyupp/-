<?php


namespace app\model;


use think\Model;

class UserModel extends Model
{
    protected $table="user";
}