<?php


namespace app\model;


use think\Model;

class AskModel extends Model
{
    protected $table="response";
}