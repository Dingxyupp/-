<?php


namespace app\model;


use think\Model;

class PaintBrushModel extends Model
{
    protected $table="paintbrush";
}