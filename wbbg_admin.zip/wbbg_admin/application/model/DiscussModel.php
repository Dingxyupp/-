<?php


namespace app\model;


use think\Model;

class DiscussModel extends Model
{
    protected $table="discuss";
}