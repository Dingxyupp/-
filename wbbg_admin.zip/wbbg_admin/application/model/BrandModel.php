<?php


namespace app\model;


use think\Model;

class BrandModel extends Model
{
    protected $table="brand";
}