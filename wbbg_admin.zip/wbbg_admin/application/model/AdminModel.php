<?php


namespace app\model;

use think\Model;
class AdminModel extends Model
{
    protected $table="admin";
}