<?php


namespace app\model;


use think\Model;

class OrderModel extends Model
{
    protected $table="order";
}