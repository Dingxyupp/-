<?php


namespace app\model;


use think\Model;

class IndexShowModel extends Model
{
    protected $table="indexshow";
}