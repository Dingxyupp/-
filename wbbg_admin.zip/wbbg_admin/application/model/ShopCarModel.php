<?php


namespace app\model;


use think\Model;

class ShopCarModel extends Model
{
    protected $table="shopcar";
}