<?php


namespace app\model;


use think\Model;

class ServeOrderModel extends Model
{
    protected $table="serveorder";
}