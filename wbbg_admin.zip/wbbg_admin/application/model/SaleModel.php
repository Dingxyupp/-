<?php


namespace app\model;


use think\Model;

class SaleModel extends  Model
{
    protected $table="money";
}