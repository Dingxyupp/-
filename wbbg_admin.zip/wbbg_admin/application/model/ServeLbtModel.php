<?php


namespace app\model;


use think\Model;

class ServeLbtModel extends Model
{
 protected $table="servelbt";
}