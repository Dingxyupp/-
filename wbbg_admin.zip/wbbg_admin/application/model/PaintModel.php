<?php


namespace app\model;


use think\Model;

class PaintModel extends Model
{
 protected $table="paint";
}