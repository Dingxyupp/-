<?php


namespace app\model;


use think\Model;

class ResponseModel extends Model
{
    protected $table="response";
}