<?php


namespace app\model;


use think\Model;

class BrushDiscussModel extends Model
{
    protected $table="brushdiscuss";
}