<?php


namespace app\api\controller;


use app\model\AskModel;
use app\model\UserModel;

class Ask
{
    function select()
    {
        $state=input("get.state");
        $page=input("get.page");
        $size=input("get.size");
        $start=($page-1)*$size;
        $end=$page*$size;
        $R=AskModel::where("state",$state)->select();
        $r=AskModel::where("state",$state)->limit($start,$end)->select();
        if (isset($r)) {
            return json(["code" => 200,"total"=>$R, "data" => $r]);
        } else {
            return json(["code" => 400]);
        }
    }

    function answer()
    {
        $id=input("post.id");
        $r=AskModel::where("id",$id)->find();
        if($r){
            return json(["code" => 200,"data"=>$r, "msg" => "获取数据成功!"]);
        }else{
            return json(["code" => 400]);
        }
    }

    function alert()
    {
        $id=input("post.id");
        $answer=input("post.answer");
        $r=AskModel::where("id",$id)->find();
        if($r){
            $r=AskModel::where("id",$id)->update(["answer"=>$answer,"state"=>2]);
            if($r){
                return json(["code" => 200, "msg" => "更新成功!"]);
            }else{
                return json(["code" => 400,"id"=>$id]);
            }
        }else{
            return json(["code" => 401]);
        }
    }

    function delete()
    {
        $data = input("get.");
        if (isset($data["id"])) {
            $id = $data["id"];
            $r = AskModel::where("id", $id)->delete();
            if ($r) {
                return json(["msg" => "删除成功", "code" => 200]);
            } else {
                return json(["msg" => "删除失败", "code" => 400]);
            }
        } else {
            return json(["msg" => "删除失败", "code" => 400]);
        }

    }

    function getAnswer(){
        $userid = input("get.")["userid"];
        $d=AskModel::where("userid",$userid)->find();
        if($d){
            return json(["code"=>200,"data"=>$d]);
        }else{
            return json(["code"=>400,"msg"=>"暂无数据"]);
        }
    }
    function doneReady(){
        $userid=session("userid");
        $d=AskModel::where("userid",$userid)->update(["readystate"=>2]);
        if($d){
            return json(["code"=>200,"msg"=>"修改成功"]);
        }else{
            return json(["code"=>400,"msg"=>"修改失败"]);
        }
    }
    function subQuestion(){
        $data = input("post.")["data"];
        $userid=session("userid");
        $r=AskModel::where("id",$userid)->find();
        if(isset($r)){
            $R=AskModel::where("id",$userid)->update(["content"=>$data["question"],"answer"=>"暂无回复","date"=>$data["date"],"state"=>1,"readystate"=>1]);
            if($R){
                return json(["code"=>200,"msg"=>"修改成功"]);
            }else{
                json(["code"=>400,"msg"=>"修改失败"]);
            }
        }else{
            $d=UserModel::where("userid",$userid)->find();
            if(!$d->username){
                return json(["code"=>401,"msg"=>"信息未补全!"]);
            }
            $ask=new AskModel();
            $ask->id=$d->userid;
            $ask->userid=$d->userid;
            $ask->username=$d->username;
            $ask->date=$data["date"];
            $ask->content=$data["question"];
            $ask->answer="暂无回复";
            $m=$ask->save();
            if($m){
                return json(["code"=>200,"msg"=>"新增成功"]);
            }else{
                return json(["code"=>402,"msg"=>"新增失败"]);
            }
        }
    }
}