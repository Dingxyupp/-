<?php


namespace app\api\controller;


use app\model\BrushDiscussModel;
use app\model\DiscussModel;
use app\model\OrderModel;
use app\model\ShopCarModel;
use app\model\UserModel;

class Order
{
    function select()
    {
        $state=input("get.state");
        $page=input("get.page");
        $size=input("get.size");
        $start=($page-1)*$size;
        $end=$page*$size;
        $R=OrderModel::where("state",$state)->select();
        $r=OrderModel::where("state",$state)->limit($start,$end)->select();
        if (isset($r)) {
            return json(["code" => 200,"total"=>$R, "data" => $r]);
        } else {
            return json(["code" => 400]);
        }
    }

    function alert()
    {
        $orderid=input("post.id");
        $state=input("post.state");
        $r=OrderModel::where("orderid",$orderid)->find();
        if($r){
            $r=OrderModel::where("orderid",$orderid)->update(["state"=>$state]);
            $R=OrderModel::where("state",$state)->select();
            if($r){
                return json(["code" => 200,"total"=>$R,"msg" => "更新成功"]);
            }else{
                return json(["code" => 402]);
            }
        }else{
            return json(["code" => 400]);
        }
    }

    function delete()
    {
        $data = input("get.");
        if (isset($data["id"])) {
            $id = $data["id"];
            $r = OrderModel::where("orderid", $id)->delete();
            $R=OrderModel::where("state",3)->select();
            if ($r) {
                return json(["msg" => "删除成功","total"=>$R, "code" => 200]);
            } else {
                return json(["msg" => "删除失败", "code" => 401]);
            }
        } else {
            return json(["msg" => "删除失败", "code" => 400]);
        }
    }
    function  search()
    {
        $content=input("post.search");

        $where['orderid|userid|goodsid|goodsname|count|packing|money|phone|nickname|username|color|address'] = array('like','%'.$content.'%');
        $v=OrderModel::where($where)->select();
        if(isset($v)){
            return json(["msg" => "查找成功", "code" => 200,"data"=>$v]);
        }else{
            return json(["code"=>400,"msg"=>"找不到您要查询的内容!"]);
        }
    }
    function look()
    {
//        查看userid的所有订单
        $userid=input("get.userid");
        $r=OrderModel::where("userid",$userid)->select();
        if($r){
            return json(["msg" => "查找成功", "code" => 200,"data"=>$r]);
        }else{
            return json(["code" => 400]);
        }
    }
    function looklogistics()
    {
        $orderid=input("get.id");
        $r=OrderModel::where("orderid",$orderid)->find();
        if($r){
            return json(["code" => 200,"msg" => "更新成功","data"=>$r]);
        }else{
            return json(["code" => 402]);
        }
    }

    function managelogistics()
    {
      $orderid=input("post.id");
      $prov=input("post.prov");
      $city=input("post.city");
      $district=input("post.district");
      $r=OrderModel::where("orderid",$orderid)->find();
      if($r){
          $r=OrderModel::where("orderid",$orderid)->update(["logistics"=>$prov.$city.$district]);
          if($r){
              return json(["code" => 200,"msg" => "更新成功"]);
          }else{
              return json(["code" => 401]);
          }
      }else{
          return json(["code" => 402]);
      }
    }

    function selectSend(){
        $userid=session("userid");
        $page=input("get.page");
        $limit=input("get.limit");
        $start=($page-1)*$limit;
        $end=$page*$limit;
        $d=OrderModel::where("userid",$userid)->where("state","<","5")->limit($start,$end)->select();
        $r=OrderModel::where("userid",$userid)->where("state","<","5")->select();

        foreach ($d as $v){
            if($v->state==1||$v->state==2||$v->state==3){
                $v->state="未发货";
            }else if($v->state==4){
                $v->state="已发货";
            }
        }

        if($d){
            return json(["code"=>0,"msg"=>"查找成功","count"=>count($r),"data"=>$d]);
        }else{
            echo 404;
        }

    }

    function lookLog(){
    $userid=session("userid");
    $page=input("get.page");
    $limit=input("get.limit");
    $start=($page-1)*$limit;
    $end=$page*$limit;
    $d=OrderModel::where("userid",$userid)->where("state","=","4")->limit($start,$end)->select();
    $r=OrderModel::where("userid",$userid)->where("state","=","4")->select();


    if($d){
        return json(["code"=>0,"msg"=>"查找成功","count"=>count($r),"data"=>$d]);
    }else{
        return json(["code"=>0,"msg"=>"查找成功","count"=>count($r),"data"=>$d]);
    }
}
    function makeSh(){
                $data=input("post.")["data"];
                $orderid=$data["orderid"];
                $finishdate=$data["finishdate"];
                $d=OrderModel::where("orderid",$orderid)->update(["state"=>5,"finishdate"=>$finishdate]);
                if($d){
                    return json(["code"=>200,"msg"=>"更新成功"]);
                }
    }
    function makeSure(){
        $userid=session("userid");
        $page=input("get.page");
        $limit=input("get.limit");
        $start=($page-1)*$limit;
        $end=$page*$limit;
        $d=OrderModel::where("userid",$userid)->where("state","=","5")->limit($start,$end)->select();
        $r=OrderModel::where("userid",$userid)->where("state","=","5")->select();
        foreach ($d as $v){
            if($v->state==5){
                $v->state="已完成";
            }
        }
        if($d){
            return json(["code"=>0,"msg"=>"查找成功","count"=>count($r),"data"=>$d]);
        }else{
            return json(["code"=>0,"msg"=>"查找成功","count"=>count($r),"data"=>$d]);
        }
    }

    function toAppraise(){
        $userid=session("userid");
        $page=input("get.page");
        $limit=input("get.limit");
        $start=($page-1)*$limit;
        $end=$page*$limit;
        $d=OrderModel::where("userid",$userid)->where("state",">",4)->where("appraisestate",0)->limit($start,$end)->select();
        $r=OrderModel::where("userid",$userid)->where("state",">",4)->where("appraisestate",0)->select();
        if($d){
            return json(["code"=>0,"msg"=>"查找成功","count"=>count($r),"data"=>$d]);
        }else{
            return json(["code"=>0,"msg"=>"查找成功","count"=>count($r),"data"=>$d]);
        }
    }
    function appraise(){
        $userid=session("userid");
        $page=input("get.page");
        $limit=input("get.limit");
        $start=($page-1)*$limit;
        $end=$page*$limit;
        $d=OrderModel::where("userid",$userid)->where("state",">",4)->where("appraisestate",1)->limit($start,$end)->select();
        $r=OrderModel::where("userid",$userid)->where("state",">",4)->where("appraisestate",1)->select();
        if($d){
            return json(["code"=>0,"msg"=>"查找成功","count"=>count($r),"data"=>$d,"userid"=>$userid]);
        }else{
            return json(["code"=>0,"msg"=>"查找失败","count"=>count($r),"data"=>$d]);
        }
    }
    function lookOrder(){
        $userid=session("userid");
        $page=input("get.page");
        $limit=input("get.limit");
        $start=($page-1)*$limit;
        $end=$page*$limit;
        $d=OrderModel::where("userid",$userid)->limit($start,$end)->select();
        $r=OrderModel::where("userid",$userid)->select();
        foreach ($d as $v){
            if($v->paystate==0){
                $v->paystate="取消支付";
            }else if($v->paystate==1){
                $v->paystate="已支付";
            }
        }
        if($d){
            return json(["code"=>0,"msg"=>"查找成功","count"=>count($r),"data"=>$d]);
        }else{
            echo 404;
        }
    }
    function deleteOrder(){
        $id=input("post.")["id"];
        $r=OrderModel::where("orderid",$id)->delete();
        if($r){
            return json(["code"=>0,"msg"=>"删除成功"]);
        }else{
            echo 404;
        }
    }
    function addDiscuss(){
        $data=input("post.")["data"];
        $orderid=$data["orderid"];
        $r=OrderModel::where("orderid",$orderid)->find();
        OrderModel::where("orderid",$orderid)->update(["appraisestate"=>1,"commonets"=>$data["commonent"]]);
        if($r->category===1){
            $dis=new DiscussModel();
            $dis->userid=$r->userid;
            $dis->goodsname=$r->goodsname;
            $dis->username=$r->username;
            $dis->goodsid=$r->goodsid;;
            $dis->commonent=$data["commonent"];
            $dis->date=$data["date"];
            $dis->packing=$r->packing;
            $dis->state=$data["state"];
           $dis->save();
        }else if($r->category===2){
            $dis1=new BrushDiscussModel();
            $dis1->userid=$r->userid;
            $dis1->goodsname=$r->goodsname;
            $dis1->username=$r->username;
            $dis1->goodsid=$r->goodsid;;
            $dis1->commonent=$data["commonent"];
            $dis1->date=$data["date"];
            $dis1->packing=$r->packing;
            $dis1->state=$data["state"];
            $dis1->save();
        }
            return json(["code"=>0,"msg"=>"添加成功"]);
    }

    function addData(){
        $data=input("post.")["data"];
        $userid=session("userid");
        $u=UserModel::where("userid",$userid)->find();
        foreach($data as $v){
            ShopCarModel::where("shopcarid",$v["shopcarid"])->update(["paystate"=>1]);
            $order=new OrderModel();
            $order->goodsid=$v["goodsid"];
            $order->category=$v["goodsstate"];
            $order->userid=$userid;
            $order->money=$v["price"];
            $order->picture=$v["picture"];
            $order->packing=$v["packing"];
            $order->goodsname=$v["goodsname"];
            $order->count=$v["count"];
            $order->color=$v["color"];
            $order->date=$v["addtime"];
            $order->nickname=$u["account"];
            $order->username=$u["username"];
            $order->phone=$u["phone"];
            $order->address=$u["address"];
            $order->finishdate="";
            $order->logistics="";
            $order->commonets="";
            $order->save();
        }
        return json(["code"=>200,"addtime"=>$data[0]["addtime"]]);
    }
    function changePayState(){
        $date=input("post.")["date"];
        $r=OrderModel::where("date",$date)->select();
        foreach($r as $v){
            OrderModel::where("orderid",$v["orderid"])->update(["paystate"=>1]);
        }
        return json(["code"=>200,"msg"=>"更新支付状态成功"]);
    }
}