<?php


namespace app\api\controller;


use app\model\UserModel;

class User
{
    function select()
    {
        $page=input("get.page");
        $size=input("get.size");
        $start=($page-1)*$size;
        $end=$page*$size;
        $R=UserModel::select();
        $r=UserModel::limit($start,$end)->select();
        if (isset($r)) {
            return json(["code" => 200,"total"=>$R, "data" => $r]);
        } else {
            return json(["code" => 400]);
        }
    }
    function personMsg(){
        $userid=input("get.")["userid"];
        $d=UserModel::where("userid",$userid)->find();
        if($d){
            return json(["code"=>"200","msg"=>"查找成功","data"=>$d]);
        }else{
            return json(["code"=>"400","msg"=>"查找失败"]);
        }
    }
    function update(){
        $userid=input("post.")["userid"];
        $data=input("post.")["data"];
        $d=UserModel::where("userid",$userid)->update(["headpicture"=>$data["headpicture"],"username"=>$data["username"],"sex"=>$data["sex"],"phone"=>$data["phone"],"address"=>$data["address"],"cardnumber"=>$data["cardnumber"],]);
        if($d){
            return json(["code"=>"200","msg"=>"修改成功"]);
        }else{
            return json(["code"=>"400","msg"=>"修改失败"]);
        }
    }

}