<?php


namespace app\api\controller;


use app\model\OrderModel;
use app\model\SaleModel;

class Sale
{
    function select()
    {
        $page=input("get.page");
        $size=input("get.size");
        $start=($page-1)*$size;
        $end=$page*$size;
        $v=OrderModel::where("state",5)->where("checkstate",0)->select();
        $R=SaleModel::select();
        $money= new SaleModel();
        if($v){
            for ($i=0; $i<count($v); $i++) {
                for($j=0; $j<count($R); $j++){
                    if($v[$i]->goodsid===$R[$j]->goodsid){
                        $R[$j]->todaymoney +=$v[$i]->money;
                        $R[$j]->daytotalmoney +=$v[$i]->money;
                        SaleModel::where("goodsid",$R[$j]->goodsid)->update(["todaymoney"=>$R[$j]->todaymoney,"daytotalmoney"=>$R[$j]->daytotalmoney]);
                        OrderModel::where("orderid",$v[$i]->orderid)->update(["checkstate"=>1]);
                    }
                    if(!SaleModel::where("goodsid",$v[$i]->goodsid)->find()){
                        $money->goodsid=$v[$i]->goodsid;
                        $money->goodsname=$v[$i]->goodsname;
                        $money->todaymoney=$v[$i]->money;
                        $money->yesmoney=0;
                        $money->yestotalmoney=0;
                        $money->daytotalmoney=$v[$i]->money;
                        $money->save();
                    }
                }
            }
        }
        $d=SaleModel::select();
        $r=SaleModel::limit($start,$end)->select();
        if (isset($r)) {
            return json(["code" => 200,"total"=>$d, "data" => $r]);
        } else {
            return json(["code" => 400]);
        }
    }
    function  search()
    {
        $content=input("post.search");
        $page=input("get.page");
        $size=input("get.size");
        $start=($page-1)*$size;
        $end=$page*$size;
        $where['goodsid|goodsname|todaymoney|yesmoney|daygain|yestotalmoney|daytotalmoney|totalmoneygain'] = array('like','%'.$content.'%');
        $v=SaleModel::where($where)->select();
        $R=SaleModel::where($where)->limit($start,$end)->select();
        if(isset($v)){
            return json(["msg" => "查找成功", "code" => 200,"data"=>$v,"total"=>$R]);
        }else{
            return json(["code"=>400,"msg"=>"找不到您要查询的内容!"]);
        }
    }
}