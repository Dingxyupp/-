<?php


namespace app\api\controller;


use app\model\BrandModel;

class Brand
{
  function select(){
      $r=BrandModel::find();
      if($r){
          return json(["code" => 200, "msg" => "查找成功!","data"=>$r]);
      }else{
          return json(["code" => 400]);
      }
  }
  function modify(){
      $content=input("post.content");
      $r=BrandModel::where("id",1)->update(["text"=>$content]);
      if($r){
          return json(["code" => 200, "msg" => "更新成功!"]);
      }else{
          return json(["code" => 400]);
      }
      }
  }