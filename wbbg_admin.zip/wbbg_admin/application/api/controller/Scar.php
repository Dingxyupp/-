<?php


namespace app\api\controller;


use app\model\PaintModel;
use app\model\ShopCarModel;

class Scar
{
    function select(){
        $userid=session("userid");
        $page=input("get.page");
        $limit=input("get.limit");
        $start=($page-1)*$limit;
        $end=$page*$limit;
        $d=ShopCarModel::where("userid",$userid)->where("paystate",0)->limit($start,$end)->select();
        $r=ShopCarModel::where("userid",$userid)->where("paystate",0)->select();
        if($d){
            return json(["code"=>0,"msg"=>"查找成功","count"=>count($r),"data"=>$d]);
        }else{
            return json(["code"=>0,"msg"=>"查找失败","count"=>count($r),"data"=>$d]);
        }
        }
    function add(){
      $data=input("post.")["data"];
      $scar=new ShopCarModel();
      $scar->userid=$data["userid"];
      $scar->addtime=$data["addtime"];
      $scar->price=$data["price"];
      $scar->goodsid=$data["goodsid"];
      $scar->goodsname=$data["goodsname"];
      $scar->picture=$data["picture"];
      $scar->color=$data["color"];
      $scar->count=$data["count"];
      $scar->packing=$data["packing"];
      $scar->goodsstate=$data["goodsstate"];
      $d=$scar->save();
      if($d){
          return json(["msg"=>"添加成功","code"=>200]);
      }else{
          return json(["msg"=>"添加失败","code"=>400]);
      }
  }
    function countAdd(){
        $userid=session("userid");
        $count=input("post.")["count"];
        $shopcarid=input("post.")["shopcarid"];
        $goodsid=input("post.")["goodsid"];
        $paint=PaintModel::where("id",$goodsid)->find();
        $price=$paint->price;
        $d=ShopCarModel::where("shopcarid",$shopcarid)->update(["count"=>$count,"price"=>$price*$count]);
        $r=ShopCarModel::where("userid",$userid)->select();
        if($d){
            if($r){
                return json(["code"=>0,"msg"=>"查找成功","count"=>count($r),"data"=>$r]);
            }
        }else{
            return json(["mag"=>"更新失败"]);
        }
    }
    function countSub(){
        $userid=session("userid");
        $count=input("post.")["count"];
        $shopcarid=input("post.")["shopcarid"];
        $goodsid=input("post.")["goodsid"];
        $res1=ShopCarModel::where("shopcarid",$shopcarid)->find();
        $res=PaintModel::where("id",$goodsid)->find();
        $price1=$res1->price;
        $price=$res->price;
        $d=ShopCarModel::where("shopcarid",$shopcarid)->update(["count"=>$count,"price"=>$price1-$price]);
        $r=ShopCarModel::where("userid",$userid)->select();
        if($d){
            if($r){
                return json(["code"=>0,"msg"=>"查找成功","count"=>count($r),"data"=>$r]);
            }
        }else{
            return json(["mag"=>"更新失败"]);
        }
    }
    function delete(){
        $shopcarid=input("post.")["shopcarid"];
        $userid=session("userid");
        $r=ShopCarModel::where("shopcarid",$shopcarid)->delete();
        $d=ShopCarModel::where("userid",$userid)->select();
        if($d){
            if($r){
                return json(["code"=>0,"msg"=>"查找成功","count"=>count($d),"data"=>$d]);
            }
        }else{
            return json(["mag"=>"更新失败"]);
        }
    }
}