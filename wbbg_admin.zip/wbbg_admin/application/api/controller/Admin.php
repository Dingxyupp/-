<?php


namespace app\api\controller;


use app\model\AdminModel;
use app\model\RoleModel;
use app\model\UserModel;
use think\captcha\Captcha;

class Admin
{
    function createHash(){
        return md5(time());
    }

    function createPassword($pass,$hash){
        return md5(sha1($pass).$hash);
    }

    function captcha(){
        $config =    [
            // 验证码字体大小
            'fontSize'    =>    30,
            // 验证码位数
            'length'      =>    4,
        ];
        $captcha = new Captcha($config);
        return $captcha->entry();
    }
    function login(){
        $username=input("post.username");
        $password=input("post.password");
        $cap=input("post.captcha");
        $captcha=new Captcha();
        if(!$captcha->check($cap)){
            return json(["msg"=>"验证码错误","code"=>400]);
        }
        $message=AdminModel::where("username",$username)->find();
        if(isset($message)){
            $id=$message->id;
            $username=$message->username;
            $role=$message->role;
//            $route=RoleModel::where("role",$message->role)->find()->route;
            $pass=$this->createPassword($password,$message->hash);
            if($message->password==$pass){
                return json(["msg"=>"登陆成功","code"=>200,"id"=>$id,"username"=>$username,"role"=>$role]);
            }else{
                return json(["msg"=>"密码错误","code"=>400]);
            }
        }else{
            return json(["msg"=>"用户名不存在","code"=>400]);
        }
    }

    function password(){
        $data=input("put.");//$data传来的是数组
        $username=$data["username"];
        $r=AdminModel::where("username",$username)->find();
        if(isset($r)){
            if($r->password===$this->createPassword($data["password"],$r->hash)){
                $res=$r->save(["password"=>$this->createPassword($data["newpassword"],$r->hash)]);
                if($res){
                    return json(["msg"=>"修改成功","code"=>200]);
                }
            }else{
                return json(["msg"=>"与原始密码不一致","code"=>1001]);
            }
        }else{
            return json(["msg"=>"用户名错误!","code"=>400]);
        }
    }
    function select(){
        $page=input("get.page");
        $size=input("get.size");
        $start=($page-1)*$size;
        $end=$page*$size;
        $R=AdminModel::select();
        $r=AdminModel::limit($start,$end)->select();
        if (isset($r)) {
            return json(["code" => 200,"total"=>$R, "data" => $r]);
        } else {
            return json(["code" => 400]);
        }
    }
    function alter()
    {
        $username=input("post.username");
        $password=input("post.password");
        $hash=$this->createHash();
        $password=$this->createPassword($password,$hash);
        $admin=new AdminModel();
        $admin->username=$username;
        $admin->password=$password;
        $admin->hash=$hash;
        $r=$admin->save();
            if($r){
                return json(["code" => 200,"msg" => "新增成功"]);
            }else{
                return json(["code" => 402]);
            }

    }
    function search()
    {
        $content=input("post.search");
        $page=input("post.page");
        $size=input("post.size");
        $start=($page-1)*$size;
        $end=$page*$size;
        $where['id|username|role'] = array('like','%'.$content.'%');
        $v=AdminModel::where($where)->select();
        $R=AdminModel::where($where)->limit($start,$end)->select();
        if(isset($v)){
            return json(["msg" => "查找成功", "code" => 200,"data"=>$v,"total"=>$R]);
        }else{
            return json(["code"=>400,"msg"=>"找不到您要查询的内容!"]);
        }
    }
    function upgrade(){
      $id=input("post.id");
      $r=AdminModel::where("id",$id)->find();
      if($r){
          $r=AdminModel::where("id",$id)->update(["role"=>0]);
          if($r){
              return json(["code" => 200,"msg"=>"更新成功"]);
          }else{
              return json(["code" => 401]);
          }
      }else {
            return json(["code" => 400]);
        }
    }
    function down(){
        $id=input("post.id");
        $r=AdminModel::where("id",$id)->find();
        if($r){
            $r=AdminModel::where("id",$id)->update(["role"=>1]);
            if($r){
                return json(["code" => 200,"msg"=>"更新成功"]);
            }else{
                return json(["code" => 401]);
            }
        }else {
            return json(["code" => 400]);
        }
    }
    function delete(){
        $data = input("get.");
        if (isset($data["id"])) {
            $id = $data["id"];
            $r = AdminModel::where("id", $id)->delete();
            $R=AdminModel::select();
            if ($r) {
                return json(["msg" => "删除成功","total"=>$R, "code" => 200]);
            } else {
                return json(["msg" => "删除失败", "code" => 401]);
            }
        } else {
            return json(["msg" => "删除失败", "code" => 400]);
        }
    }
    function webLogin(){
        $data=input("post.")["loginMes"];
        $account=$data["account"];
        $pass=$data["pass"];
        $d=UserModel::where("account",$account)->find();
        if(isset($d)){
            if($d->password===$pass){
                session("userid",$d->userid);
                return json(["msg"=>"该用户存在","code"=>200,"userid"=>$d->userid]);
            }else{
                return json(["msg"=>"密码不正确","code"=>402]);
            }
        }else{
            return json(["msg"=>"不存在该用户","code"=>401]);
        }
    }
    function webRegister(){
        $data=input("post.")["registerMes"];
        $account=$data["account"];
        $pass=$data["pass"];
        $repass=$data["repass"];
        $d=UserModel::where("account",$account)->find();
        if(isset($d)){
            return json(["msg"=>"该用户名已经存在","code"=>400]);
        }else{
            $res=new UserModel();
            $res->account=$account;
            $res->password=$pass;
            $r=$res->save();
            if($r){
                return json(["msg"=>"新增用户成功","code"=>200]);
            }else{
                return json(["msg"=>"新增用户失败","code"=>4001]);
            }
        }
    }
}