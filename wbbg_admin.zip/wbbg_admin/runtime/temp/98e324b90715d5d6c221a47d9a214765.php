<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"C:\Users\dxy\Desktop\wbbg_admin\public/../application/index\view\pages\serve.html";i:1589078296;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="/static/js/swiper.min.js"></script>
    <link rel="stylesheet" href="/static/css/index.css">
    <link rel="stylesheet" href="/static/css/swiper.min.css">
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <link rel="stylesheet" href="/static/css/serve.css">
</head>
<body>
<header>
    <img src="/static/img/ook.png" alt="" class="logo">
    <a class="hide_list1"><span class="header_serve" id="serve_serve">服务</span>
        <div class="list1">
            <li>
                <object><a href="<?php echo url('index/index/serve'); ?>" class="list_a_img"><img src="/static/img/flash.png" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p">焕新服务</p></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>#serve_example"><p class="list_p_p">刷新案例</p></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p_p">刷新服务Q&A</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>" class="list_a_img"><img src="/static/img/check.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>"><p class="list_p">墙面基检</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_wall"><p class="list_p_p">墙面问题</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_tool"><p class="list_p_p">检测工具</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_step"><p class="list_p_p">检测步骤</p></a></object>
            </li>
            <li>
                <object><a class="list_a_img" id="layui_alert_img"><img src="/static/img/serve_other.jpg" alt="" class="list_img"></a></object>
                <object><a href="" data-method="alert"  data-type="auto" id="layui_alert"><p class="list_p">其他服务</p></a></object>
            </li>
        </div>
    </a>
    <a href="<?php echo url('index/index/shop'); ?>"  class="hide_list2"><span class="header_shop" id="serve_shop">商城</span>
        <div class="list2">
            <li>
                <object><a href="<?php echo url('index/index/mallIn'); ?>" class="list_a_img"><img src="/static/img/paint_in.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p">室内漆</p></a></object>
                <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p_p">查看全部</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallOut'); ?>" class="list_a_img"><img src="/static/img/paint_out.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p">室外漆</p></a></object>
                <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p_p">查看更多</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallMu'); ?>" class="list_a_img"><img src="/static/img/paint_wood.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallMu'); ?>"><p class="list_p">木器漆</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallTu'); ?>" class="list_a_img"><img src="/static/img/paint_peijian.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallTu'); ?>"><p class="list_p">涂刷配件</p></a></object>
                <!--        <object><a href="serve.html"><p class="list_p_p">墙面底材</p></a></object>-->
                <!--        <object><a href="serve.html"><p class="list_p_p">工具</p></a></object>-->
            </li>
        </div></a>
    <a class="hide_list3"><span class="header_ask" id="serve_ask">咨询</span>
        <div class="list3">
            <li>
                <object><a href="<?php echo url('index/index/paintCalculation'); ?>" class="list_a_img"><img src="/static/img/kv0014_p.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/paintCalculation'); ?>"><p class="list_p">漆量计算</p></a></object>
            </li>
        </div></a>
    <a  class="hide_list4"><span class="header_about" id="serve_about">关于品牌</span>
        <div class="list4">
            <li>
                <object><a href="<?php echo url('index/index/aboutBrand'); ?>" class="list_a_img"><img src="/static/img/zeren1.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/aboutBrand'); ?>"><p class="list_p">关于品牌</p></a></object>
            </li>
        </div></a>
    <!--    <a href=""><span><i id="serve_search" class="layui-icon layui-icon-search header_a_search"></i></span></a>-->
    <a href="<?php echo url('index/index/shopCar'); ?>" id="judge_shopcar_href"><span><i id="serve_list" class="layui-icon layui-icon-cart-simple header_a_cart"></i></span></a>
    <a href="<?php echo url('index/index/personalCenter'); ?>" id="judge_personal_href"><span><i id="serve_user" class="layui-icon layui-icon-user header_a_user"></i></span></a>
</header>
<div class="swiper-container">
    <div class="swiper-wrapper">
        <div class="swiper-slide"><img src="/static/img/serve2.jpg" alt="" class="swiper_img1"></div>
        <div class="swiper-slide"><img src="/static/img/serve.jpg" alt="" class="swiper_img2"></div>
<!--        <div class="swiper-slide"><img src="/static/img/demo3.jpg" alt="" class="swiper_img3"></div>-->
    </div>
    <!-- 如果需要导航按钮 -->
    <!--  <div class="swiper-button-prev"></div>-->
    <!--  <div class="swiper-button-next"></div>-->
</div>
<h3>请填写以下数据来选择服务</h3>
<div class="serve_input" lay-filter="test1">
    <form class="layui-form" action="" lay-filter="serveForm">
        <div class="layui-form-item">
            <label class="layui-form-label">姓名</label>
            <div class="layui-input-block">
                <input type="text" name="username"   lay-verify="username" placeholder="请输入您的姓名" autocomplete="open" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">手机号</label>
            <div class="layui-input-block">
                <input type="text" name="phonenumber"   lay-verify="phonenumber" placeholder="请输入您的手机号" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">性别</label>
            <div class="layui-input-block">
                <input type="radio" name="sex" value="男" title="男">
                <input type="radio" name="sex" value="女" title="女" checked>
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">地址</label>
            <div class="layui-input-inline">
                <select name="province" id="province" lay-filter="province" lay-verify="required">
                    <option value="" selected="">请选择省</option>
                </select>
            </div>
            <div class="layui-input-inline" id="layui-input-inline-city">
                <select name="city" id="city" lay-filter="city" lay-verify="required">
                    <option value="" selected>请选择城市</option>
                </select>
            </div>
            <div class="layui-input-inline" id="layui-input-inline-county">
                <select name="county" id="county" lay-filter="county" lay-verify="required">
                    <option value="" selected>请选择县/区</option>
                </select>
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">详细地址</label>
            <div class="layui-input-block">
                <input type="text" name="address" lay-verify="required"   required placeholder="请输入您的家庭地址" autocomplete="open" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">服务</label>
            <div class="layui-input-block" lay-verify="select">
                <input type="checkbox" name="brushserve"  value="刷新服务" title="刷新服务">
                <input type="checkbox" name="wallcheck"  value="专业墙面基检" title="专业墙面基检">
            </div>
        </div>
        <div class="layui-form-item layui-form-text">
            <label class="layui-form-label">备注</label>
            <div class="layui-input-block">
                <textarea name="content" placeholder="请输入内容" class="layui-textarea"></textarea>
            </div>
        </div>
        <div class="layui-form-item" style="display: none">
            <div class="layui-input-block">
                <input  type="text" name="date">
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-block" style="text-align: center">
                <button class="layui-btn" lay-submit lay-filter="serveSub">提交</button>
            </div>
        </div>
    </form>
</div>
<div class="serve_example" id="serve_example"><span>精选案例</span></div>
<div class="serve_show">
    <div class="serve_show_top">
        <a href=""><img src="/static/img/serve_top.jpg" alt=""></a>
    </div>
    <div class="serve_show_down">
        <a href=""><img src="/static/img/case_tit1.jpg" alt=""></a>
        <a href=""><img src="/static/img/case_tit2.jpg" alt=""></a>
        <a href=""><img src="/static/img/case_tit3.jpg" alt=""></a>
        <a href=""><h3 class="serve_show_down_vertical">查看更多</h3></a>
    </div>
</div>
<footer>
    <p style="text-align: center">获取更多&nbsp:<a href="https://weibo.com/"><img src="/static/img/wb.png" alt=""></a><a
            href="" class="wx_hover"><img
            src="/static/img/dxy.png" alt="" class="codeleft"><img src="/static/img/wx.png" alt="" class="wxpicture"></a></p>
    <h3>联系我们&nbsp:000-000-000</h3>
</footer>
<script src="/static/layui/layui.js"></script>
<script src="/static/js/mouseEvent.js"></script>
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<script type="module">
    import address from '/static/js/address.js'//导入地址文件
    function GMTToStr(){
        var date = new Date();
        var Str=date.getFullYear() + '-' +
            (date.getMonth() + 1) + '-' +
            date.getDate() + ' ' +
            date.getHours() + ':' +
            date.getMinutes() + ':' +
            date.getSeconds()
        return Str
    }
    //拦截个人中心
    let judge_personal_href=document.getElementById("judge_personal_href");
    judge_personal_href.addEventListener("click",function (e) {
        e.preventDefault();
        if(!sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/login'); ?>")
        }else if(sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/personalCenter'); ?>")
        }
    });
    //拦截购物车
    let judge_shopcar_href=document.getElementById("judge_shopcar_href");
    judge_shopcar_href.addEventListener("click",function (e) {
        e.preventDefault();
        if(!sessionStorage.getItem("userid")){
            e.preventDefault();
            window.location.assign("<?php echo url('index/index/login'); ?>")
        }else if(sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/shopCar'); ?>")
        }
    });
    let select_province_value,select_city_value,select_county_value;//三个选择框的值
    let ades=address.provice;//导入的地址数组
    let select_province=document.getElementById("province");//省份select
    let select_city=document.getElementById("city");//城市select
    let select_county=document.getElementById("county");//县区select
    for(let i=0;i<ades.length;i++){
        let opo=document.createElement("option");
        opo.innerText=ades[i].name;
        opo.value=ades[i].name;
        select_province.appendChild(opo);
    }
    //定义插入函数
    layui.use(['form', 'element', 'laypage', 'layer'], function () {
            var element = layui.element,
                laypage = layui.laypage,
                layer = layui.layer,
                form = layui.form;
            //表单验证
        form.verify({
            username: function(value, item){ //value：表单的值、item：表单的DOM对象
                if(value.length===0){
                    return '姓名不能为空!'
                }
                if(!new RegExp("^[a-zA-Z0-9_\u4e00-\u9fa5\\s·]+$").test(value)){
                    return '姓名不能有特殊字符';
                }
                if(value.length>5){
                    return '姓名长度不得高于5'
                }
            },
            phonenumber: function(value, item){
                if(!new RegExp("^1[3456789]\\d{9}$").test(value)){
                    return '手机号格式不正确';
                }
            },
            select:function (value) {
                if((!form.val("serveForm").brushserve)&&(!form.val("serveForm").wallcheck)){
                    return '至少选一项服务'
                }
            }
        });
        //自定义样式
        laypage.render({
            elem: 'demo'
            , count: 100
            , theme: '#1E9FFF',
            prev: null,
            next: null
        })
        //监听省份select
        form.on('select(province)', function(data){
            select_province_value=data.value;//得到被选中的值
            //当选定了省份之后可以根据省份名来确定城市名
            ades.forEach(v=>{
                if(v.name===select_province_value){
                    select_city.innerHTML=`
                     <option value="" selected>请选择城市</option>
                    `;//将前边设置的option清除掉，只显示当前省份的城市
                    select_county.innerHTML=`
                     <option value="" selected>请选择区/县</option>
                    `;//将前边设置的option清除掉，只显示当前城市的区县
                    v.city.forEach(t=>{
                        let opo=document.createElement("option");
                        opo.innerText=t.name;
                        opo.value=t.name;
                        select_city.appendChild(opo);
                    })
                }
            })
            form.render();//动态操作表单   自动更新渲染
        });
        //监听城市select
        form.on('select(city)', function(data){
           select_city_value=data.value;
           //当城市确定后找出区县
            ades.forEach(v=>{
                if(v.name===select_province_value){
                    select_county.innerHTML=`
                     <option value="" selected>请选择区县</option>
                    `;//将前边设置的option清除掉，只显示当前城市的区县
                    v.city.forEach(t=>{
                        if(select_city_value===t.name){
                            t. districtAndCounty.forEach(m=>{
                                let opo=document.createElement("option");
                                opo.innerText=m;
                                opo.value=m;
                                select_county.appendChild(opo);
                            })
                        }
                    })
                }
            });
            form.render();//动态操作表单   自动更新渲染
        });
        // 监听提交
        form.on('submit(serveSub)', function (data) {
            form.val("serveForm", {
                "date":GMTToStr
            });
            let subData = form.val("serveForm");
            axios.post('/api/sorder/increase',{subData:subData}).then((res)=>{
                if(res.data.code===200){
                    console.log(res.data.wallcheck)
                    layer.alert("提交成功!",function(){
                        location.reload();
                    });
                }else{
                    layer.alert("出了点问题,请稍后再试!")
                }
            })
            return false;
        });
    });

</script>
</body>
</html>