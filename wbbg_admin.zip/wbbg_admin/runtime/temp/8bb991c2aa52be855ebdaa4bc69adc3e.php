<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:88:"C:\Users\dxy\Desktop\wbbg_admin\public/../application/index\view\pages\brush-detail.html";i:1589703032;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="/static/css/index.css">
    <link rel="stylesheet" href="/static/css/swiper.min.css">
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <link rel="stylesheet" href="/static/css/shop.css">
    <link rel="stylesheet" href="/static/css/goodsdetail.css">
</head>
<body>
<header>
    <img src="/static/img/ook.png" alt="" class="logo">
    <a class="hide_list1"><span class="header_serve" id="serve_serve">服务</span>
        <div class="list1">
            <li>
                <object><a href="<?php echo url('index/index/serve'); ?>" class="list_a_img"><img src="/static/img/flash.png" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p">焕新服务</p></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>#serve_example"><p class="list_p_p">刷新案例</p></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p_p">刷新服务Q&A</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>" class="list_a_img"><img src="/static/img/check.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>"><p class="list_p">墙面基检</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_wall"><p class="list_p_p">墙面问题</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_tool"><p class="list_p_p">检测工具</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_step"><p class="list_p_p">检测步骤</p></a></object>
            </li>
            <li>
                <object><a class="list_a_img" id="layui_alert_img"><img src="/static/img/serve_other.jpg" alt="" class="list_img"></a></object>
                <object><a href="" data-method="alert"  data-type="auto" id="layui_alert"><p class="list_p">其他服务</p></a></object>
            </li>
        </div>
    </a>
    <a href="<?php echo url('index/index/shop'); ?>"  class="hide_list2"><span class="header_shop" id="serve_shop">商城</span>
        <div class="list2">
            <li>
                <object><a href="<?php echo url('index/index/mallIn'); ?>" class="list_a_img"><img src="/static/img/paint_in.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p">室内漆</p></a></object>
                <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p_p">查看全部</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallOut'); ?>" class="list_a_img"><img src="/static/img/paint_out.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p">室外漆</p></a></object>
                <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p_p">查看更多</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallMu'); ?>" class="list_a_img"><img src="/static/img/paint_wood.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallMu'); ?>"><p class="list_p">木器漆</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallTu'); ?>" class="list_a_img"><img src="/static/img/paint_peijian.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallTu'); ?>"><p class="list_p">涂刷配件</p></a></object>
                <!--        <object><a href="serve.html"><p class="list_p_p">墙面底材</p></a></object>-->
                <!--        <object><a href="serve.html"><p class="list_p_p">工具</p></a></object>-->
            </li>
        </div></a>
    <a class="hide_list3"><span class="header_ask" id="serve_ask">咨询</span>
        <div class="list3">
            <li>
                <object><a href="<?php echo url('index/index/paintCalculation'); ?>" class="list_a_img"><img src="/static/img/kv0014_p.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/paintCalculation'); ?>"><p class="list_p">漆量计算</p></a></object>
            </li>
        </div></a>
    <a  class="hide_list4"><span class="header_about" id="serve_about">关于品牌</span>
        <div class="list4">
            <li>
                <object><a href="<?php echo url('index/index/aboutBrand'); ?>" class="list_a_img"><img src="/static/img/zeren1.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/aboutBrand'); ?>"><p class="list_p">关于品牌</p></a></object>
            </li>
        </div></a>
    <!--    <a href=""><span><i id="serve_search" class="layui-icon layui-icon-search header_a_search"></i></span></a>-->
    <a href="<?php echo url('index/index/shopCar'); ?>" id="judge_shopcar_href"><span><i id="serve_list" class="layui-icon layui-icon-cart-simple header_a_cart"></i></span></a>
    <a href="<?php echo url('index/index/personalCenter'); ?>" id="judge_personal_href"><span><i id="serve_user" class="layui-icon layui-icon-user header_a_user"></i></span></a>
</header>
<?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
<div class="sc_index">
    <h1 class="goods_title" id="goods_name"><?php echo $v['name']; ?></h1>
    <div class="sc_index_img">
        <img src="<?php echo $v['picture']; ?>" alt="" id="goods_picture">
    </div>
    <div class="sc_index_option">
        <div class="sc_index_option_packing">
            <form class="layui-form" lay-filter="add_shopCar_form">


                <div class="layui-form-item" id="select">
                    <label class="layui-form-label" style="text-align: center">数量</label>
                    <div class="layui-input-block">
                        <input type="text" name="count" required lay-verify="required" class="layui-input" value="1" style="width: 30%;padding-left: 0px;text-align: center;float: left">
                        <button type="button"  lay-submit style="float:right;height:38px;" class="layui-btn layui-btn-sm layui-btn-primary" lay-filter="subtraction" id="subtraction">
                            <i class="layui-icon layui-icon-subtraction"></i>
                        </button>
                        <button type="button"  lay-submit style="float:right;height:38px;border-right: none;" class="layui-btn layui-btn-sm layui-btn-primary" lay-filter="addition">
                            <i class="layui-icon layui-icon-addition"></i>
                        </button>
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label" style="text-align: center">价格</label>
                    <div class="layui-input-block">
                        <input type="text" name="price" required disabled lay-verify="required" class="layui-input" value="<?php echo $v['price']; ?>" style="width: 30%;padding-left: 0px;text-align: center;float: left">
                    </div>
                </div>

                <div class="layui-form-item">
                    <div class="layui-input-block" style="margin-left: 16%;">
                        <button class="layui-btn layui-btn-danger" lay-submit lay-filter="add_shopCar_sub" style="width:100%">加入购物车</button>
                    </div>
                </div>

                <div class="layui-form-item" style="display: none">
                    <div class="layui-input-block">
                        <input  type="text" name="addtime">
                    </div>
                </div>

                <div class="layui-form-item" style="display: none">
                    <div class="layui-input-block">
                        <input  type="text" name="picture">
                    </div>
                </div>

                <div class="layui-form-item" style="display: none">
                    <div class="layui-input-block">
                        <input  type="text" name="userid">
                    </div>
                </div>

                <div class="layui-form-item" style="display: none">
                    <div class="layui-input-block">
                        <input  type="text" name="goodsid">
                    </div>
                </div>

                <div class="layui-form-item" style="display: none">
                    <div class="layui-input-block">
                        <input  type="text" name="goodsstate">
                    </div>
                </div>

                <div class="layui-form-item" style="display: none">
                    <div class="layui-input-block">
                        <input  type="text" name="goodsname">
                    </div>
                </div>

                <div class="layui-form-item" style="display: none">
                    <div class="layui-input-block">
                        <input  type="text" name="color">
                    </div>
                </div>

                <div class="layui-form-item" style="display: none">
                    <div class="layui-input-block">
                        <input  type="text" name="packing">
                    </div>
                </div>


            </form>
        </div>
    </div>
</div>
<?php endforeach; endif; else: echo "" ;endif; ?>
<div class="layui-tab layui-tab-card" style="margin: 0 50px;">
    <ul class="layui-tab-title">
        <li class="layui-this">商品介绍</li>
        <li>用户评论</li>
    </ul>
    <div class="layui-tab-content">
        <!--        商品介绍-->
        <div class="layui-tab-item layui-show">
            <div class="sc_desc">
                <div class="sc_desc_left">
                    <div class="product_introduce">
                        <h2>产品介绍</h2>
                        <p style="font-size: 17px;line-height: 30px;white-space: pre-line"><?php echo $v['productintd']; ?></p>
                    </div>
                </div>
                <div class="sc_desc_right">
                    <div class="product_introduce">
                        <h2>产品介绍</h2>
                        <p style="font-size: 17px;line-height: 30px;"><?php echo $v['productintd']; ?></p>
                    </div>
                    <div class="detail_introduce">
                        <h2>细节介绍</h2>
                        <li style="overflow: hidden;border-bottom: 1px solid rgba(102,102,102,0.1)">
                            <p style="margin:20px 0;">
                                <i class="layui-icon layui-icon-snowflake" style="float: left;color: #666;font-size: 28px;"></i>
                            <div style="float: left;margin: 0 10px;font-size: 18px;color:#2fc48d">规格</div>
                            <p style="float: left;font-size: 18px;"><?php echo $v['specifications']; ?></p>
                            </p>
                        </li>
                        <li style="overflow: hidden;border-bottom: 1px solid rgba(102,102,102,0.1)">
                            <p style="margin:20px 0;">
                                <i class="layui-icon layui-icon-template-1" style="float: left;color: #666;font-size: 28px;"></i>
                            <div style="float: left;margin: 0 10px;font-size: 18px;color:#2fc48d">工具清洗</div>
                            <p style="float: left;font-size: 18px;"><?php echo $v['cleaning']; ?> </p>
                            </p>
                        </li>
                        <li style="overflow: hidden;border-bottom: 1px solid rgba(102,102,102,0.1)">
                            <p style="margin:20px 0;">
                                <i class="layui-icon layui-icon-log" style="float: left;color: #666;font-size: 28px;"></i>
                            <div style="float: left;margin: 0 10px;font-size: 18px;color:#2fc48d">施工温度</div>
                            <p style="float: left;font-size: 18px;"><?php echo $v['temperature']; ?></p>
                            </p>
                        </li>
                        <li style="overflow: hidden;border-bottom: 1px solid rgba(102,102,102,0.1)">
                            <p style="margin:20px 0;">
                                <i class="layui-icon layui-icon-fonts-clear" style="float: left;color: #666;font-size: 28px;"></i>
                            <div style="float: left;margin: 0 10px;font-size: 18px;color:#2fc48d">施工方法</div>
                            <p style="float: left;font-size: 18px;"><?php echo $v['method']; ?></p>
                            </p>
                        </li>
                    </div>
                </div>
            </div>
        </div>
        <!--        用户评论-->
        <div class="layui-tab-item">
            <div class="sc_evaluation">
                <div class="layui-tab layui-tab-brief">
                    <ul class="layui-tab-title">
                        <li class="layui-this">全部评论</li>
                        <li>好评</li>
                        <li>中评</li>
                        <li>差评</li>
                    </ul>
                    <div class="layui-tab-content">

                        <div class="layui-tab-item layui-show">
                            <div class="layui-row">
                                <?php if(is_array($res) || $res instanceof \think\Collection || $res instanceof \think\Paginator): $i = 0; $__LIST__ = $res;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$p): $mod = ($i % 2 );++$i;?>
                                <div class="layui-col-md12">
                                    <div class="layui-card" style="box-shadow: 0 0 5px;margin-bottom: 15px">
                                        <div class="layui-card-header"><?php echo $p['username']; ?></div>
                                        <div class="layui-card-body">
                                            <!--                                            内容-->
                                            <div class="layui-row" style="margin: 15px 0">
                                                <div class="layui-col-md12">
                                                    <?php echo $p['commonent']; ?>
                                                </div>
                                            </div>
                                            <!--                                            其他-->
                                            <div class="layui-row">
                                                <div class="layui-col-md2">
                                                    <?php echo $p['packing']; ?>件
                                                </div>
                                                <div class="layui-col-md2">
                                                    <?php echo $p['date']; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </div>
                        </div>
                        <div class="layui-tab-item">
                            <div class="layui-row">
                                <?php if(is_array($good_res) || $good_res instanceof \think\Collection || $good_res instanceof \think\Paginator): $i = 0; $__LIST__ = $good_res;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$o): $mod = ($i % 2 );++$i;?>
                                <div class="layui-col-md12">
                                    <div class="layui-card" style="box-shadow: 0 0 5px;margin-bottom: 15px">
                                        <div class="layui-card-header"><?php echo $o['username']; ?></div>
                                        <div class="layui-card-body">
                                            <!--                                            内容-->
                                            <div class="layui-row" style="margin: 15px 0">
                                                <div class="layui-col-md12">
                                                    <?php echo $o['commonent']; ?>
                                                </div>
                                            </div>
                                            <!--                                            其他-->
                                            <div class="layui-row">
                                                <div class="layui-col-md2">
                                                    <?php echo $o['packing']; ?>
                                                </div>
                                                <div class="layui-col-md2">
                                                    <?php echo $o['date']; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </div>
                        </div>
                        <div class="layui-tab-item">
                            <div class="layui-row">
                                <?php if(is_array($middle_res) || $middle_res instanceof \think\Collection || $middle_res instanceof \think\Paginator): $i = 0; $__LIST__ = $middle_res;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$z): $mod = ($i % 2 );++$i;?>
                                <div class="layui-col-md12">
                                    <div class="layui-card" style="box-shadow: 0 0 5px;margin-bottom: 15px">
                                        <div class="layui-card-header"><?php echo $z['username']; ?></div>
                                        <div class="layui-card-body">
                                            <!--                                            内容-->
                                            <div class="layui-row" style="margin: 15px 0">
                                                <div class="layui-col-md12">
                                                    <?php echo $z['commonent']; ?>
                                                </div>
                                            </div>
                                            <!--                                            其他-->
                                            <div class="layui-row">
                                                <div class="layui-col-md2">
                                                    <?php echo $z['packing']; ?>
                                                </div>
                                                <div class="layui-col-md2">
                                                    <?php echo $z['date']; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </div>
                        </div>
                        <div class="layui-tab-item">
                            <div class="layui-row">
                                <?php if(is_array($bad_res) || $bad_res instanceof \think\Collection || $bad_res instanceof \think\Paginator): $i = 0; $__LIST__ = $bad_res;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$c): $mod = ($i % 2 );++$i;?>
                                <div class="layui-col-md12">
                                    <div class="layui-card" style="box-shadow: 0 0 5px;margin-bottom: 15px">
                                        <div class="layui-card-header"><?php echo $c['username']; ?></div>
                                        <div class="layui-card-body">
                                            <!--                                            内容-->
                                            <div class="layui-row" style="margin: 15px 0">
                                                <div class="layui-col-md12">
                                                    <?php echo $c['commonent']; ?>
                                                </div>
                                            </div>
                                            <!--                                            其他-->
                                            <div class="layui-row">
                                                <div class="layui-col-md2">
                                                    <?php echo $c['packing']; ?>
                                                </div>
                                                <div class="layui-col-md2">
                                                    <?php echo $c['date']; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<footer>
    <p style="text-align: center">获取更多&nbsp:<a href="https://weibo.com/"><img src="/static/img/wb.png" alt=""></a><a
            href="" class="wx_hover"><img
            src="/static/img/dxy.png" alt="" class="codeleft"><img src="/static/img/wx.png" alt="" class="wxpicture"></a></p>
    <h3>联系我们&nbsp:000-000-000</h3>
</footer>
<script src="/static/js/swiper.min.js"></script>
<script src="/static/layui/layui.js"></script>
<script src="/static/js/mouseEvent.js"></script>
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<script>
    let subtraction=document.getElementById("subtraction");
    let goodsid=sessionStorage.getItem('goodsid');

    //向控制器发送goodsid
    // axios.post("/index/index/goodsdetail",{data:123}).then(res=>{
    //     console.log(res.data)
    // });

    //拦截个人中心
    let judge_personal_href=document.getElementById("judge_personal_href");
    judge_personal_href.addEventListener("click",function (e) {
        e.preventDefault();
        if(!sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/login'); ?>")
        }else if(sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/personalCenter'); ?>")
        }
    });
    //拦截购物车
    let judge_shopcar_href=document.getElementById("judge_shopcar_href");
    judge_shopcar_href.addEventListener("click",function (e) {
        e.preventDefault();
        if(!sessionStorage.getItem("userid")){
            e.preventDefault();
            window.location.assign("<?php echo url('index/index/login'); ?>")
        }else if(sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/shopCar'); ?>")
        }
    });
    //时间转化
    function GMTToStr(){
        var date = new Date();
        var Str=date.getFullYear() + '-' +
            (date.getMonth() + 1) + '-' +
            date.getDate() + ' ' +
            date.getHours() + ':' +
            date.getMinutes() + ':' +
            date.getSeconds()
        return Str
    }
    //拿到商品id之后就去后台请求对应的商品，然后把返回来的数据渲染到当前页面中
    //接受一下goodsid，判断产品id，向数据库发送goodsid找到产品渲染到页面上
    if(goodsid){
        //   发送请求获取数据，将回调后的数据渲染到页面上
    }else{
        //    错误页?
    }
    layui.use(['layer', 'form','element'], function () {
        var layer = layui.layer,
            $ =layui.jquery,
            element = layui.element;
        form = layui.form;
        //获取picture
        let goods_picture=document.getElementById("goods_picture");
        //获取goodsname
        let goods_name=document.getElementById("goods_name");
        //自定义数量
        form.on('submit(search)', function(data){
            search_button.outerHTML=`
<form class="layui-form" action="" lay-filter="goods_search_form">
    <div class="layui-input-inline" style="height: 100%;width:100%">
      <input type="text" id="search_input" name="searchvalue" lay-verify="required" placeholder="请输入您要查询的产品" autocomplete="off" class="layui-input">
      <button type="button" lay-filter="goods_search_submit" lay-submit id="serve_submit" class="layui-btn layui-btn-danger" style="width: 20%;height:96%">
  <i class="layui-icon layui-icon-search"></i>
</button>
    </div>
    </form>
            `;
            form.render();
        });
        //数量加操作
        let price=Number(form.val("add_shopCar_form").price);
        let count=Number(form.val("add_shopCar_form").count);
        form.on('submit(addition)', function(data){
            form.val("add_shopCar_form", {
                "count":++count,
                "price":price*count
            });
            form.render()
        });
        //数量减操作
        form.on('submit(subtraction)', function(data){
            let subPrice=Number(form.val("add_shopCar_form").price);

            if(count===1){
                return;
            }
            form.val("add_shopCar_form", {
                "count":--count,
                "price":subPrice-price
            });
            form.render()
        });
        //    点击加入购物车时先获取表单数据，添加到购物车数据库里
        form.on('submit(add_shopCar_sub)',function (data) {
            form.val("add_shopCar_form", {
                "addtime":GMTToStr(),
                "picture":goods_picture.src,
                "userid":sessionStorage.getItem("userid"),
                "goodsname":goods_name.innerText,
                "goodsid":goodsid,
                "goodsstate":2,
                "color":"",
                "packing":"件"
            });
            var data1 = form.val("add_shopCar_form");
            console.log(data1);
            axios.post("/api/scar/add",{data:data1}).then(res=>{
                if(res.data.code===200){
                    if(!sessionStorage.getItem("userid")){
                        layer.alert("请先登录!");
                    }else{
                        layer.alert("加入购物车成功!")
                    }
                }
            });
            return false;//阻止表单跳转
        })
    });
</script>
</body>
</html>