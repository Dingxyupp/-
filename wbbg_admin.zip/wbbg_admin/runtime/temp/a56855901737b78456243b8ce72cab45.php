<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:86:"C:\Users\dxy\Desktop\wbbg_admin\public/../application/index\view\pages\toappraise.html";i:1589698805;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <title>Title</title>
    <style>
        .ta_main{
            padding:70px 60px;
            margin-top: 96px;
            width:auto;
            height:500px;
            background: url(https://www.dulux.com.cn/profiles/flourish/themes/custom/flourish_rem/images/vertical-shade.jpg);
        }
    </style>
    <link rel="stylesheet" href="/static/css/index.css">
    <link rel="stylesheet" href="/static/css/swiper.min.css">
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <!--    <link rel="stylesheet" href="/static/css/shop.css">-->
    <link rel="stylesheet" href="/static/css/peosoncenter.css">
</head>
<body>
<header>
    <img src="/static/img/ook.png" alt="" class="logo">
    <a class="hide_list1"><span class="header_serve" id="serve_serve">服务</span>
        <div class="list1">
            <li>
                <object><a href="<?php echo url('index/index/serve'); ?>" class="list_a_img"><img src="/static/img/flash.png" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p">焕新服务</p></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>#serve_example"><p class="list_p_p">刷新案例</p></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p_p">刷新服务Q&A</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>" class="list_a_img"><img src="/static/img/check.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>"><p class="list_p">墙面基检</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_wall"><p class="list_p_p">墙面问题</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_tool"><p class="list_p_p">检测工具</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_step"><p class="list_p_p">检测步骤</p></a></object>
            </li>
            <li>
                <object><a class="list_a_img" id="layui_alert_img"><img src="/static/img/serve_other.jpg" alt="" class="list_img"></a></object>
                <object><a href="" data-method="alert"  data-type="auto" id="layui_alert"><p class="list_p">其他服务</p></a></object>
            </li>
        </div>
    </a>
    <a href="<?php echo url('index/index/shop'); ?>"  class="hide_list2"><span class="header_shop" id="serve_shop">商城</span>
        <div class="list2">
            <li>
                <object><a href="<?php echo url('index/index/mallIn'); ?>" class="list_a_img"><img src="/static/img/paint_in.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p">室内漆</p></a></object>
                <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p_p">查看全部</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallOut'); ?>" class="list_a_img"><img src="/static/img/paint_out.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p">室外漆</p></a></object>
                <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p_p">查看更多</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallMu'); ?>" class="list_a_img"><img src="/static/img/paint_wood.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallMu'); ?>"><p class="list_p">木器漆</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallTu'); ?>" class="list_a_img"><img src="/static/img/paint_peijian.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallTu'); ?>"><p class="list_p">涂刷配件</p></a></object>
                <!--        <object><a href="serve.html"><p class="list_p_p">墙面底材</p></a></object>-->
                <!--        <object><a href="serve.html"><p class="list_p_p">工具</p></a></object>-->
            </li>
        </div></a>
    <a class="hide_list3"><span class="header_ask" id="serve_ask">咨询</span>
        <div class="list3">
            <li>
                <object><a href="<?php echo url('index/index/paintCalculation'); ?>" class="list_a_img"><img src="/static/img/kv0014_p.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/paintCalculation'); ?>"><p class="list_p">漆量计算</p></a></object>
            </li>
        </div></a>
    <a  class="hide_list4"><span class="header_about" id="serve_about">关于品牌</span>
        <div class="list4">
            <li>
                <object><a href="<?php echo url('index/index/aboutBrand'); ?>" class="list_a_img"><img src="/static/img/zeren1.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/aboutBrand'); ?>"><p class="list_p">关于品牌</p></a></object>
            </li>
        </div></a>
    <!--    <a href=""><span><i id="serve_search" class="layui-icon layui-icon-search header_a_search"></i></span></a>-->
    <a href="<?php echo url('index/index/shopCar'); ?>" id="judge_shopcar_href"><span><i id="serve_list" class="layui-icon layui-icon-cart-simple header_a_cart"></i></span></a>
    <a href="<?php echo url('index/index/personalCenter'); ?>" id="judge_personal_href"><span><i id="serve_user" class="layui-icon layui-icon-user header_a_user"></i></span></a>
</header>
<div class="ta_main">
    <div class="layui-tab layui-tab-brief" lay-filter="docDemoTabBrief">
        <ul class="layui-tab-title">
            <li data-status="" class="layui-this">待评价</li>
            <li data-status="1">已评价</li>
        </ul>
        <div class="layui-tab-content">
            <div class="layui-tab-item layui-show">
            <table class="layui-table" lay-even lay-skin="nob" lay-size="lg" id="da_notable" lay-filter="order-table1">
            </table>
            </div>
            <div class="layui-tab-item">
                <table class="layui-table" lay-even lay-skin="nob" lay-size="lg" id="da_donetable" lay-filter="order-table2">
                </table>
            </div>
    </div>
</div>
</div>
<footer>
    <p style="text-align: center">获取更多&nbsp:<a href="https://weibo.com/"><img src="/static/img/wb.png" alt=""></a><a
            href="" class="wx_hover"><img
            src="/static/img/dxy.png" alt="" class="codeleft"><img src="/static/img/wx.png" alt="" class="wxpicture"></a></p>
    <h3>联系我们&nbsp:000-000-000</h3>
</footer>
<script type="text/html" id="barDemo">
    <div class="site-demo-button" id="layerDemo" style="margin-bottom: 0;">
    <button type="button" lay-submit class="layui-btn layui-btn-danger" lay-event="addAre" lay-filter="addAre">
        <i class="layui-icon">&#xe65f;</i>
    </button>
    </div>
</script>
<script src="/static/layui/layui.js"></script>
<script src="/static/js/swiper.min.js"></script>
<script src="/static/js/mouseEvent.js"></script>
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<script>
    function GMTToStr(){
        var date = new Date();
        var Str=date.getFullYear() + '-' +
            (date.getMonth() + 1) + '-' +
            date.getDate() + ' ' +
            date.getHours() + ':' +
            date.getMinutes() + ':' +
            date.getSeconds()
        return Str
    }
    //拦截个人中心
    let judge_personal_href=document.getElementById("judge_personal_href");
    judge_personal_href.addEventListener("click",function (e) {
        e.preventDefault();
        if(!sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/login'); ?>")
        }else if(sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/personalCenter'); ?>")
        }
    });
    //拦截购物车
    let judge_shopcar_href=document.getElementById("judge_shopcar_href");
    judge_shopcar_href.addEventListener("click",function (e) {
        e.preventDefault();
        if(!sessionStorage.getItem("userid")){
            e.preventDefault();
            window.location.assign("<?php echo url('index/index/login'); ?>")
        }else if(sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/shopCar'); ?>")
        }
    });
    layui.use(['table','element','layer','form'], function(){
        var table = layui.table,
            element =layui.element,
            form=layui.form,
            $=layui.jquery,
            layer = layui.layer;

         //渲染表格
        getList('#da_notable',status='',"toappraise");
        // 选项卡切换
        element.on('tab(docDemoTabBrief)', function(data){
            var status = $(this).attr('data-status');
            var position = '',method='';
            switch (status) {
                case '1': position = '#da_donetable';method='appraise'; break;
                case '0': position = '#da_notable'; method='toappraise';break;
            }
            getList(position, status,method)
        });
        // 公共方法
        function getList(position, status = '',method){
            table.render({
                elem: position
                ,url:'/api/order/'+method
                ,page:{limit:5}
                ,where: {
                    status: status
                }
                ,cols: [[
                    {field:'orderid', width:80,title: '订单号'},
                    {field:'goodsname', width:400,title: '商品名'},
                    {field:'picture', width:200,title: '缩略图',templet:'<div><img src="{{ d.picture }}" style="width:30px; height:30px;"></div>'},
                    {field:'finishdate', width:150,title: '完成时间'},
                    {field:'count', width:100,title: '数量'},
                    {field:'money', width:80,title: '金额'},
                    {field:'username', width:80,title: '收货人'},
                    {field:'commonets', width:180,title: '评论'},
                    {fixed: 'right', align:'center', toolbar: '#barDemo'},
                ]]

            });
        }

        table.on('tool(order-notable)', function(obj){
            var data = obj.data;
            if(obj.event === 'appraise'){
                layer.confirm('删除该条记录吗?', function(index){
                    //拿到该
                    layer.close(index);
                });
            }
        });


        //行工具事件
        table.on('tool(order-table1)', function(obj) {
            var data = obj.data;
            if (obj.event === 'addAre') {
                let index=layer.open({
                    type: 1
                    , title: false //不显示标题栏
                    , closeBtn: false
                    , area: '500px;'
                    , shade: 0.8
                    , id: 'LAY_layuipro' //设定一个id，防止重复弹出
                    , btn: ['提交', '取消']
                    , btnAlign: 'c'
                    , moveType: 1 //拖拽模式，0或者1
                    , content: `
<div style="padding: 10px; line-height: 22px; background-color: #393D49; color: #fff; font-weight: 300;">
<form class="layui-form" lay-filter="plSub">
<div class="layui-form-item">
    <label class="layui-form-label" style="text-align: center;padding: 9px 0px;width: 70px">满意度</label>
    <div class="layui-input-block" style="margin-left: 80px;">
      <select name="state" lay-verify="required" style="display: block;width: 70%;height:38px;">
        <option value="1">好评</option>
        <option value="2">中评</option>
        <option value="3">差评</option>
      </select>
    </div>
  </div>

<div class="layui-form-item">
    <label class="layui-form-label" style="text-align: center;padding: 9px 0px;width: 70px">评论</label>
    <div class="layui-input-block" style="margin-left: 80px;">
      <input type="text" style="width:70%;"  name="commonent" value="" class="layui-input">
    </div>
  </div>

<div class="layui-form-item">
    <div class="layui-input-block" style="display: none;">
      <input type="text" name="date" value="" class="layui-input">
    </div>
  </div>
  </form>
</div> `
                    , yes: function (layero) {
                        let data=form.val("plSub");
                        data.orderid=obj.data.orderid;
                        data.date=GMTToStr();
                        axios.post("/api/order/adddiscuss", {data: data}).then(res=>{
                            if(res.data.code===0){
                                layer.close(index);
                                layer.alert("评论成功!",function(index){
                                    obj.del();
                                    layer.close(index);
                                })
                            }
                        })
                    }
                });
            }
        })
    });
</script>
</body>
</html>