<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"C:\Users\dxy\Desktop\wbbg_admin\public/../application/index\view\pages\mall-out.html";i:1589446292;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="/static/css/index.css">
    <link rel="stylesheet" href="/static/css/swiper.min.css">
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <link rel="stylesheet" href="/static/css/mall.css">
</head>
<body>
<header>
    <img src="/static/img/ook.png" alt="" class="logo">
    <a class="hide_list1"><span class="header_serve" id="serve_serve">服务</span>
        <div class="list1">
            <li>
                <object><a href="<?php echo url('index/index/serve'); ?>" class="list_a_img"><img src="/static/img/flash.png" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p">焕新服务</p></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>#serve_example"><p class="list_p_p">刷新案例</p></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p_p">刷新服务Q&A</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>" class="list_a_img"><img src="/static/img/check.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>"><p class="list_p">墙面基检</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_wall"><p class="list_p_p">墙面问题</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_tool"><p class="list_p_p">检测工具</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_step"><p class="list_p_p">检测步骤</p></a></object>
            </li>
            <li>
                <object><a class="list_a_img" id="layui_alert_img"><img src="/static/img/serve_other.jpg" alt="" class="list_img"></a></object>
                <object><a href="" data-method="alert"  data-type="auto" id="layui_alert"><p class="list_p">其他服务</p></a></object>
            </li>
        </div>
    </a>
    <a href="<?php echo url('index/index/shop'); ?>"  class="hide_list2"><span class="header_shop" id="serve_shop">商城</span>
        <div class="list2">
            <li>
                <object><a href="<?php echo url('index/index/mallIn'); ?>" class="list_a_img"><img src="/static/img/paint_in.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p">室内漆</p></a></object>
                <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p_p">查看全部</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallOut'); ?>" class="list_a_img"><img src="/static/img/paint_out.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p">室外漆</p></a></object>
                <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p_p">查看更多</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallMu'); ?>" class="list_a_img"><img src="/static/img/paint_wood.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallMu'); ?>"><p class="list_p">木器漆</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallTu'); ?>" class="list_a_img"><img src="/static/img/paint_peijian.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallTu'); ?>"><p class="list_p">涂刷配件</p></a></object>
                <!--        <object><a href="serve.html"><p class="list_p_p">墙面底材</p></a></object>-->
                <!--        <object><a href="serve.html"><p class="list_p_p">工具</p></a></object>-->
            </li>
        </div></a>
    <a class="hide_list3"><span class="header_ask" id="serve_ask">咨询</span>
        <div class="list3">
            <li>
                <object><a href="<?php echo url('index/index/paintCalculation'); ?>" class="list_a_img"><img src="/static/img/kv0014_p.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/paintCalculation'); ?>"><p class="list_p">漆量计算</p></a></object>
            </li>
            <li>
                <object><a class="list_a_img" id="my_question"><img src="/static/img/star.png" alt="" class="list_img"></a></object>
                <object><a ><p class="list_p">我要提问</p></a></object>
            </li>
        </div></a>
    <a  class="hide_list4"><span class="header_about" id="serve_about">关于品牌</span>
        <div class="list4">
            <li>
                <object><a href="<?php echo url('index/index/aboutBrand'); ?>" class="list_a_img"><img src="/static/img/zeren1.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/aboutBrand'); ?>"><p class="list_p">关于品牌</p></a></object>
            </li>
        </div></a>
    <!--    <a href=""><span><i id="serve_search" class="layui-icon layui-icon-search header_a_search"></i></span></a>-->
    <a href="<?php echo url('index/index/shopCar'); ?>" id="judge_shopcar_href"><span><i id="serve_list" class="layui-icon layui-icon-cart-simple header_a_cart"></i></span></a>
    <a href="<?php echo url('index/index/personalCenter'); ?>" id="judge_personal_href"><span><i id="serve_user" class="layui-icon layui-icon-user header_a_user"></i></span></a>
</header>
<div class="mall_main">
    <div class="mall_main_left">
        <!--        搜索-->
        <div class="mall_search">
            <button type="button" lay-submit lay-filter="search" class="layui-btn layui-btn-primary layui_search" id="search_button">
                <i class="layui-icon layui-icon-search"></i>
            </button>
        </div>
        <div class="mall_other_three">
            <div class="layui-collapse" id="category_top_collapse" lay-accordion>
                <form class="layui-form" action="" lay-filter="goods_screening_father">
                    <!--                产品系列-->
                    <div class="layui-colla-item">
                        <div class="layui-colla-title">产品系列</div>
                        <div class="layui-colla-content layui-show">
                            <div class="layui-form-item">
                                <div class="layui-block">
                                    <input type="radio" name="series" value="全部" title="全部" lay-filter="category_all" checked="" style="display: block;visibility: hidden">
                                    <input type="radio" name="series" value="底漆" title="底漆" lay-filter="category_di" style="display: block;visibility: hidden">
                                    <input type="radio" name="series" value="面漆" title="面漆" lay-filter="category_mian" style="display: block;visibility: hidden">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--                用途-->
                    <div class="layui-colla-item">
                        <div class="layui-colla-title">用途</div>
                        <div class="layui-colla-content ">
                            <div class="layui-form-item">
                                <div class="layui-block">
                                    <input type="radio" name="use" value="墙壁" title="墙壁" lay-filter="goods_screening" checked style="display: block;visibility: hidden">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--                光泽-->
                    <div class="layui-colla-item">
                        <div class="layui-colla-title">光泽</div>
                        <div class="layui-colla-content ">
                            <div class="layui-form-item">
                                <div class="layui-block">
                                    <input type="radio" name="color" value="哑光" title="哑光" lay-filter="category_yg" style="display: block;visibility: hidden">
                                    <input type="radio" name="color" value="高光" title="高光" lay-filter="category_gg" style="display: block;visibility: hidden">
                                    <input type="radio" name="color" value="柔光" title="柔光" lay-filter="category_rg" style="display: block;visibility: hidden">
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--    <div id="goodsPage">-->
    <ul class="mall_main_right" id="mall_main_right">
        <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
        <li>
            <a href="<?php echo url('index/index/goodsDetail',['id'=>$v['id']]); ?>" class="mall_main_right_a" ><img src="<?php echo $v['picture']; ?>" alt="" data-goodsid="<?php echo $v['id']; ?>"></a>
            <p style="text-align: center;font-size: 16px;"><?php echo $v['name']; ?></p>
            <div class="mall_main_right_feature">
                <p>
                    <i class="layui-icon layui-icon-ok" style="color: #2fc48d;font-size: 20px"></i>
                    &nbsp&nbsp<?php echo $v['property']; ?>
                </p>
            </div>
            <p class="arrow_around">
                <a href="<?php echo url('index/index/goodsDetail',['id'=>$v['id']]); ?>" class="arrow_around_a">
                    <i class="arrow layui-icon layui-icon-right" data-goodsid="4"></i>
                </a>
            </p>
        </li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
        <div id="demo"></div>
    </ul>
    <!--    </div>-->
    <div id="page" style="float:left;text-align: center;line-height:120px;width:100%;height:120px;"></div>
</div>
<footer>
    <p style="text-align: center">获取更多&nbsp:<a href="https://weibo.com/"><img src="/static/img/wb.png" alt=""></a><a
            href="" class="wx_hover"><img
            src="/static/img/dxy.png" alt="" class="codeleft"><img src="/static/img/wx.png" alt="" class="wxpicture"></a></p>
    <h3>联系我们&nbsp:000-000-000</h3>
</footer>
<script src="/static/layui/layui.js"></script>
<script src="/static/js/mouseEvent.js"></script>
<script src="/static/js/swiper.min.js"></script>
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<script>
    let search_button=document.getElementById("search_button");
    let mall_main_right=document.getElementById("mall_main_right");
    //拦截个人中心
    let judge_personal_href=document.getElementById("judge_personal_href");
    judge_personal_href.addEventListener("click",function (e) {
        e.preventDefault();
        if(!sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/login'); ?>")
        }else if(sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/personalCenter'); ?>")
        }
    });
    //拦截购物车
    let judge_shopcar_href=document.getElementById("judge_shopcar_href");
    judge_shopcar_href.addEventListener("click",function (e) {
        e.preventDefault();
        if(!sessionStorage.getItem("userid")){
            e.preventDefault();
            window.location.assign("<?php echo url('index/index/login'); ?>")
        }else if(sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/shopCar'); ?>")
        }
    });
    //给图片和跳转图标上都加了goodsid自定义属性，渲染数据的时候把商品id放进去。然后当我点击时，session存了goodsid，
    //商品详情页拿到goodsid，去数据库找到该商品将数据渲染到页面上，实现单页面显示不同商品效果。
    mall_main_right.onclick=function(e){
        let goodsid=e.target.dataset.goodsid;
        sessionStorage.setItem("goodsid",goodsid);
    }

    //接受一下categoryid，判断产品种类，向数据库发送categoryid筛选相应产品渲染到页面上
    let categoryid=sessionStorage.getItem("categoryid");
    //count记录返回了多少数据，用于分页
    let count=0;
    if(categoryid){
        axios.get("/api/paint/selectcategory",{params:{
                categoryid:categoryid
            }}).then(res=>{
            if(res.data.code===200){
                count=res.data.data.length;
                console.log(count);
            }
        })
    }else{
        layer.alert("出现错误!")
    }

    layui.use(['layer', 'form','laypage','element'], function(){
        var layer = layui.layer,
            laypage = layui.laypage,
            element=layui.element,
            $=layui.jquery,
            form = layui.form;

        //我要提问
        let question = document.getElementById("my_question");
        question.onclick=function(){
            layer.open({
                type: 1
                ,title: false //不显示标题栏
                ,closeBtn: true
                ,area: '500px;'
                ,shade: 0.8
                ,id: 'LAY_layuipro' //设定一个id，防止重复弹出
                ,btn: ['提交','取消']
                ,btnAlign: 'c'
                ,moveType: 1 //拖拽模式，0或者1
                ,content: `
        <div class="layui-card">
          <div class="layui-card-header">我要提问</div>
          <div class="layui-card-body">
            <form class="layui-form" lay-filter="quesForm">
              <div class="layui-form-item layui-form-text">
                <label class="layui-form-label" style="text-align: center">请输入问题</label>
                <div class="layui-input-block">
                  <textarea name="question" placeholder="请输入内容" class="layui-textarea"></textarea>
                </div>
              </div>

              <div class="layui-form-item">
                <div class="layui-input-block" style="display: none">
                  <input type="text" name="date" class="layui-input">
                </div>
              </div>
            </form>
          </div>
        </div>
        `
                ,yes: function(index, layero){
                    //do something
                    form.val("quesForm",{
                        date:GMTToStr()
                    });
                    axios.post("/api/ask/subquestion",{data:form.val("quesForm")}).then(res=>{
                        if(res.data.code==200){
                            layer.close(index); //如果设定了yes回调，需进行手工关闭
                            layer.alert("提交成功!请等待管理员回复!")
                        }else if(res.data.code==401){
                            layer.close(index);
                            layer.alert("请您先补全个人信息再来咨询!")
                        }else{
                            layer.close(index);
                            layer.alert("提交失败!")
                        }
                    });
                },
            });
        }

        //拿到分页所需的所有li
        var a = $("ul#mall_main_right li");
        //建立一个数组放置li里的元素
        var zz =new Array(a.length);
        //拼接li
        for(let i=0;i <a.length;i++){
            zz[i]=a[i].innerHTML;
            zz[i]="<li>"+zz[i]+"</li>";

        };
        //搜索栏
        form.on('submit(goods_search_submit)',function(data){
            let searchdata=form.val('goods_search_form');
            axios.get("/api/paint/searchgoods",{params:{
                    categoryid:categoryid,
                    data:searchdata.searchvalue
                }}).then(res=>{
                    if(res.data.code===200){
                        let arr1=[];
                        count=res.data.data.length;
                        let data1=res.data.data;
                        if(data1.length===0) {
                            layer.alert("暂无数据", function () {
                                location.reload();
                            });
                        }
                        for(let i=0;i<data1.length;i++){
                            arr1.push(`<li>
               <a href='<?php echo url("index/index/goodsDetail"); ?>?id=${data1[i].id}' class="mall_main_right_a" ><img src=${data1[i].picture} alt="" data-goodsid=${data1[i].id}></a>
               <p style="text-align: center;font-size: 16px;">${data1[i].name}</p>
               <div class="mall_main_right_feature">
                   <p>
                       <i class="layui-icon layui-icon-ok" style="color: #2fc48d;font-size: 20px"></i>
                       &nbsp&nbsp${data1[i].property}
                   </p>
               </div>
              <p class="arrow_around">
                  <a href="<?php echo url("index/index/goodsDetail"); ?>?id=${data1[i].id}" class="arrow_around_a">
                      <i class="arrow layui-icon layui-icon-right" data-goodsid=${data1.id}></i>
                  </a>
              </p>
        </li>`)
                        }
                        console.log(arr1);
                        //重新渲染分页
                        laypage.render({
                            elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
                            , count: count
                            ,limit:6//每页数量
                            ,theme: '#FFB800'//自定义颜色
                            ,jump: function(obj){
                                let mall_main_right=document.getElementById('mall_main_right');
                                let start=obj.curr*obj.limit - obj.limit;
                                let end=obj.curr*obj.limit;
                                mall_main_right.innerHTML=arr1.slice(start,end).join("");
                            }
                        })
                    }
                }
            );
        });
        //筛选栏事件-全部
        form.on('radio(category_all)', function(data){
            location.reload();
        });
        //筛选栏事件-底漆
        form.on('radio(category_di)', function(data){
            axios.get("/api/paint/series",{params:{
                    categoryid:categoryid,
                    series:data.value
                }}).then(res=>{
                if(res.data.code===200){
                    let arr1=[];
                    count=res.data.data.length;
                    let data1=res.data.data;
                    for(let i=0;i<data1.length;i++){
                        arr1.push(`<li>
               <a href='<?php echo url("index/index/goodsDetail"); ?>?id=${data1[i].id}' class="mall_main_right_a" ><img src=${data1[i].picture} alt="" data-goodsid=${data1[i].id}></a>
               <p style="text-align: center;font-size: 16px;">${data1[i].name}</p>
               <div class="mall_main_right_feature">
                   <p>
                       <i class="layui-icon layui-icon-ok" style="color: #2fc48d;font-size: 20px"></i>
                       &nbsp&nbsp${data1[i].property}
                   </p>
               </div>
              <p class="arrow_around">
                  <a href="<?php echo url("index/index/goodsDetail"); ?>?id=${data1[i].id}" class="arrow_around_a">
                      <i class="arrow layui-icon layui-icon-right" data-goodsid=${data1.id}></i>
                  </a>
              </p>
        </li>`)
                    }
                    console.log(arr1);
                    //重新渲染分页
                    laypage.render({
                        elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
                        , count: count
                        ,limit:6//每页数量
                        ,theme: '#FFB800'//自定义颜色
                        ,jump: function(obj){
                            let mall_main_right=document.getElementById('mall_main_right');
                            let start=obj.curr*obj.limit - obj.limit;
                            let end=obj.curr*obj.limit;
                            mall_main_right.innerHTML=arr1.slice(start,end).join("");
                        }
                    })
                }
            })
        });
        //筛选栏事件-面漆
        form.on('radio(category_mian)', function(data){
            axios.get("/api/paint/series",{params:{
                    categoryid:categoryid,
                    series:data.value
                }}).then(res=>{
                if(res.data.code===200){
                    let arr1=[];
                    count=res.data.data.length;
                    let data1=res.data.data;
                    for(let i=0;i<data1.length;i++){
                        arr1.push(`<li>
               <a href='<?php echo url("index/index/goodsDetail"); ?>?id=${data1[i].id}' class="mall_main_right_a" ><img src=${data1[i].picture} alt="" data-goodsid=${data1[i].id}></a>
               <p style="text-align: center;font-size: 16px;">${data1[i].name}</p>
               <div class="mall_main_right_feature">
                   <p>
                       <i class="layui-icon layui-icon-ok" style="color: #2fc48d;font-size: 20px"></i>
                       &nbsp&nbsp${data1[i].property}
                   </p>
               </div>
              <p class="arrow_around">
                  <a href="<?php echo url("index/index/goodsDetail"); ?>?id=${data1[i].id}" class="arrow_around_a">
                      <i class="arrow layui-icon layui-icon-right" data-goodsid=${data1.id}></i>
                  </a>
              </p>
        </li>`)
                    }
                    //重新渲染分页
                    laypage.render({
                        elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
                        , count: count
                        ,limit:6//每页数量
                        ,theme: '#FFB800'//自定义颜色
                        ,jump: function(obj){
                            let mall_main_right=document.getElementById('mall_main_right');
                            let start=obj.curr*obj.limit - obj.limit;
                            let end=obj.curr*obj.limit;
                            mall_main_right.innerHTML=arr1.slice(start,end).join("");
                        }
                    })
                }
            })
        });
        //筛选栏事件-哑光
        form.on('radio(category_yg)', function(data){
            axios.get("/api/paint/color",{params:{
                    categoryid:categoryid,
                    color:data.value
                }}).then(res=>{
                if(res.data.code===200){
                    let arr1=[];
                    count=res.data.data.length;
                    let data1=res.data.data;
                    for(let i=0;i<data1.length;i++){
                        arr1.push(`<li>
               <a href='<?php echo url("index/index/goodsDetail"); ?>?id=${data1[i].id}' class="mall_main_right_a" ><img src=${data1[i].picture} alt="" data-goodsid=${data1[i].id}></a>
               <p style="text-align: center;font-size: 16px;">${data1[i].name}</p>
               <div class="mall_main_right_feature">
                   <p>
                       <i class="layui-icon layui-icon-ok" style="color: #2fc48d;font-size: 20px"></i>
                       &nbsp&nbsp${data1[i].property}
                   </p>
               </div>
              <p class="arrow_around">
                  <a href="<?php echo url("index/index/goodsDetail"); ?>?id=${data1[i].id}" class="arrow_around_a">
                      <i class="arrow layui-icon layui-icon-right" data-goodsid=${data1.id}></i>
                  </a>
              </p>
        </li>`)
                    }
                    //重新渲染分页
                    laypage.render({
                        elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
                        , count: count
                        ,limit:6//每页数量
                        ,theme: '#FFB800'//自定义颜色
                        ,jump: function(obj){
                            let mall_main_right=document.getElementById('mall_main_right');
                            let start=obj.curr*obj.limit - obj.limit;
                            let end=obj.curr*obj.limit;
                            mall_main_right.innerHTML=arr1.slice(start,end).join("");
                        }
                    })
                }
            })
        });
        //筛选栏事件-高光
        form.on('radio(category_gg)', function(data){
            axios.get("/api/paint/color",{params:{
                    categoryid:categoryid,
                    color:data.value
                }}).then(res=>{
                if(res.data.code===200){
                    let arr1=[];
                    count=res.data.data.length;
                    let data1=res.data.data;
                    for(let i=0;i<data1.length;i++){
                        arr1.push(`<li>
               <a href='<?php echo url("index/index/goodsDetail"); ?>?id=${data1[i].id}' class="mall_main_right_a" ><img src=${data1[i].picture} alt="" data-goodsid=${data1[i].id}></a>
               <p style="text-align: center;font-size: 16px;">${data1[i].name}</p>
               <div class="mall_main_right_feature">
                   <p>
                       <i class="layui-icon layui-icon-ok" style="color: #2fc48d;font-size: 20px"></i>
                       &nbsp&nbsp${data1[i].property}
                   </p>
               </div>
              <p class="arrow_around">
                  <a href="<?php echo url("index/index/goodsDetail"); ?>?id=${data1[i].id}" class="arrow_around_a">
                      <i class="arrow layui-icon layui-icon-right" data-goodsid=${data1.id}></i>
                  </a>
              </p>
        </li>`)
                    }
                    //重新渲染分页
                    laypage.render({
                        elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
                        , count: count
                        ,limit:6//每页数量
                        ,theme: '#FFB800'//自定义颜色
                        ,jump: function(obj){
                            let mall_main_right=document.getElementById('mall_main_right');
                            let start=obj.curr*obj.limit - obj.limit;
                            let end=obj.curr*obj.limit;
                            mall_main_right.innerHTML=arr1.slice(start,end).join("");
                        }
                    })
                }
            })
        });
        //筛选栏事件-柔光
        form.on('radio(category_rg)', function(data){
            axios.get("/api/paint/color",{params:{
                    categoryid:categoryid,
                    color:data.value
                }}).then(res=>{
                if(res.data.code===200){
                    let arr1=[];
                    count=res.data.data.length;
                    let data1=res.data.data;
                    for(let i=0;i<data1.length;i++){
                        arr1.push(`<li>
               <a href='<?php echo url("index/index/goodsDetail"); ?>?id=${data1[i].id}' class="mall_main_right_a" ><img src=${data1[i].picture} alt="" data-goodsid=${data1[i].id}></a>
               <p style="text-align: center;font-size: 16px;">${data1[i].name}</p>
               <div class="mall_main_right_feature">
                   <p>
                       <i class="layui-icon layui-icon-ok" style="color: #2fc48d;font-size: 20px"></i>
                       &nbsp&nbsp${data1[i].property}
                   </p>
               </div>
              <p class="arrow_around">
                  <a href="<?php echo url("index/index/goodsDetail"); ?>?id=${data1[i].id}" class="arrow_around_a">
                      <i class="arrow layui-icon layui-icon-right" data-goodsid=${data1.id}></i>
                  </a>
              </p>
        </li>`)
                    }
                    //重新渲染分页
                    laypage.render({
                        elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
                        , count: count
                        ,limit:6//每页数量
                        ,theme: '#FFB800'//自定义颜色
                        ,jump: function(obj){
                            let mall_main_right=document.getElementById('mall_main_right');
                            let start=obj.curr*obj.limit - obj.limit;
                            let end=obj.curr*obj.limit;
                            mall_main_right.innerHTML=arr1.slice(start,end).join("");
                        }
                    })
                }
            })
        });

        //点击搜索按钮触发的事件
        form.on('submit(search)', function(data){
            search_button.outerHTML=`
<form class="layui-form" action="" lay-filter="goods_search_form">
    <div class="layui-input-inline" style="height: 100%;width:100%">
      <input type="text" id="search_input" name="searchvalue" lay-verify="required" placeholder="请输入您要查询的产品" autocomplete="off" class="layui-input">
      <button type="button" lay-filter="goods_search_submit" lay-submit id="serve_submit" class="layui-btn layui-btn-danger" style="width: 20%;height:96%">
  <i class="layui-icon layui-icon-search"></i>
</button>
    </div>
    </form>
            `;
            form.render();
        });
        //执行一个laypage实例
        laypage.render({
            elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
            ,count: count //数据总数，从服务端得到
            ,limit:6//每页数量
            ,theme: '#FFB800'//自定义颜色
            ,jump: function(obj){
                let mall_main_right=document.getElementById('mall_main_right');
                let start=obj.curr*obj.limit - obj.limit;
                let end=obj.curr*obj.limit;
                mall_main_right.innerHTML=zz.slice(start,end);
            }
        });
    });
</script>
</body>
</html>