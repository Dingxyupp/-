<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:91:"C:\Users\dxy\Desktop\wbbg_admin\public/../application/index\view\pages\personal-center.html";i:1589440933;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="/static/css/index.css">
    <link rel="stylesheet" href="/static/css/swiper.min.css">
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <link rel="stylesheet" href="/static/css/peosoncenter.css">
</head>
<body>
<header>
    <img src="/static/img/ook.png" alt="" class="logo">
    <a class="hide_list1"><span class="header_serve" id="serve_serve">服务</span>
        <div class="list1">
            <li>
                <object><a href="<?php echo url('index/index/serve'); ?>" class="list_a_img"><img src="/static/img/flash.png" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p">焕新服务</p></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>#serve_example"><p class="list_p_p">刷新案例</p></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p_p">刷新服务Q&A</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>" class="list_a_img"><img src="/static/img/check.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>"><p class="list_p">墙面基检</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_wall"><p class="list_p_p">墙面问题</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_tool"><p class="list_p_p">检测工具</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_step"><p class="list_p_p">检测步骤</p></a></object>
            </li>
            <li>
                <object><a class="list_a_img" id="layui_alert_img"><img src="/static/img/serve_other.jpg" alt="" class="list_img"></a></object>
                <object><a href="" data-method="alert"  data-type="auto" id="layui_alert"><p class="list_p">其他服务</p></a></object>
            </li>
        </div>
    </a>
    <a href="<?php echo url('index/index/shop'); ?>"  class="hide_list2"><span class="header_shop" id="serve_shop">商城</span>
        <div class="list2">
            <li>
                <object><a href="<?php echo url('index/index/mallIn'); ?>" class="list_a_img"><img src="/static/img/paint_in.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p">室内漆</p></a></object>
                <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p_p">查看全部</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallOut'); ?>" class="list_a_img"><img src="/static/img/paint_out.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p">室外漆</p></a></object>
                <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p_p">查看更多</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallMu'); ?>" class="list_a_img"><img src="/static/img/paint_wood.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallMu'); ?>"><p class="list_p">木器漆</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallTu'); ?>" class="list_a_img"><img src="/static/img/paint_peijian.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallTu'); ?>"><p class="list_p">涂刷配件</p></a></object>
                <!--        <object><a href="serve.html"><p class="list_p_p">墙面底材</p></a></object>-->
                <!--        <object><a href="serve.html"><p class="list_p_p">工具</p></a></object>-->
            </li>
        </div></a>
    <a class="hide_list3"><span class="header_ask" id="serve_ask">咨询</span>
        <div class="list3">
            <li>
                <object><a href="<?php echo url('index/index/paintCalculation'); ?>" class="list_a_img"><img src="/static/img/kv0014_p.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/paintCalculation'); ?>"><p class="list_p">漆量计算</p></a></object>
            </li>
            <li>
                <object><a class="list_a_img" id="my_question"><img src="/static/img/star.png" alt="" class="list_img"></a></object>
                <object><a ><p class="list_p">我要提问</p></a></object>
            </li>
        </div></a>
    <a  class="hide_list4"><span class="header_about" id="serve_about">关于品牌</span>
        <div class="list4">
            <li>
                <object><a href="<?php echo url('index/index/aboutBrand'); ?>" class="list_a_img"><img src="/static/img/zeren1.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/aboutBrand'); ?>"><p class="list_p">关于品牌</p></a></object>
            </li>
        </div></a>
    <!--    <a href=""><span><i id="serve_search" class="layui-icon layui-icon-search header_a_search"></i></span></a>-->
    <a href="<?php echo url('index/index/shopCar'); ?>" id="judge_shopcar_href"><span><i id="serve_list" class="layui-icon layui-icon-cart-simple header_a_cart"></i></span></a>
    <a href="<?php echo url('index/index/personalCenter'); ?>" id="judge_personal_href"><span><i id="serve_user" class="layui-icon layui-icon-user header_a_user"></i></span></a>
</header>
<div style="width:100%;height:auto;margin-top: 96px;padding-bottom: 50px" >
<!--    卡片-->
        <div class="layui-row" >
            <div class="layui-col-md3">
                <div class="layui-card" style="height:240px;width:250px;margin-left: 240px;margin-top: 50px;box-shadow: 2px 2px 10px rgba(0,0,0,.3);">
                    <div class="layui-card-body" style="padding-top: 80px;">
                        <img src="/static/img/ook.png" alt="" style="width:70px;height:70px;margin-left: 70px">
                    </div>
                </div>
            </div>
            <div class="layui-col-md6">
                <div class="layui-card" style="height:240px;margin-left:115px;margin-top: 50px;">
                    <div class="layui-card-header" style="font-size: 22px">个人中心<a id="loginout" style="float:right;font-size: 14px">退出登录</a></div>
                    <div class="layui-card-body" id="layerMsg" style="padding-top: 60px;padding-left: 50px;padding-right: 50px">
                        <a href="delask.html" style="font-size: 22px;font-weight: 600;margin-right: 45px">发货查询</a>
                        <a href="logmange.html" style="font-size: 22px;font-weight: 600;margin-right: 45px">查看物流</a>
                        <a href="toappraise.html" style="font-size: 22px;font-weight: 600;margin-right: 45px">待评价</a>
                        <a href="order.html" style="font-size: 22px;font-weight: 600;margin-right: 45px">订单</a>
                        <a data-method="notice" id="msg" style="font-size: 22px;font-weight: 600;">信息</a>
                    </div>
                </div>
            </div>
        </div>

    <div class="layui-row">
        <div class="layui-col-md7">
            <div class="layui-card" style="margin-left: 240px;margin-top: 50px;">
                <div class="layui-card-header" style="font-size:22px">个人信息</div>
                <div class="layui-card-body">
                    <div class="layui-collapse">
                        <div class="layui-colla-item">
                            <h2 class="layui-colla-title">管理个人信息</h2>
                            <div class="layui-colla-content layui-show">
<!--                                用表单来对用户信息编辑-->

                                <form class="layui-form" lay-filter="personMsg">
                                    <div class="layui-form-item">
                                        <label class="layui-form-label">头像</label>
                                        <img id="headP" src="" alt="" style=";width: 80px;height:80px">
                                    </div>

                                    <div class="layui-form-item">
                                        <label class="layui-form-label">选择头像</label>
                                        <button  type="button" class="layui-btn" id="headpicture">
                                            <i class="layui-icon">&#xe67c;</i>上传头像
                                        </button>
                                    </div>
                                    <div class="layui-form-item">
                                    <label class="layui-form-label">真实姓名</label>
                                    <div class="layui-input-block">
                                        <input type="text" lay-verify="username" name="username" required  placeholder="请输入真实姓名" autocomplete="off" class="layui-input">
                                    </div>
                                </div>
                                    <div class="layui-form-item">
                                        <label class="layui-form-label">性别</label>
                                        <div class="layui-input-block">
                                            <input type="radio" name="sex" value="男" title="男">
                                            <input type="radio" name="sex" value="女" title="女">
                                        </div>
                                    </div>
                                    <div class="layui-form-item">
                                        <label class="layui-form-label">身份证号码</label>
                                        <div class="layui-input-block">
                                            <input type="text" lay-verify="cardnumber" name="cardnumber" required  placeholder="请输入身份证号" autocomplete="off" class="layui-input">
                                        </div>
                                    </div>
                                    <div class="layui-form-item">
                                        <label class="layui-form-label">电话</label>
                                        <div class="layui-input-block">
                                            <input type="text" lay-verify="phone" name="phone" required  placeholder="请输入电话号" autocomplete="off" class="layui-input">
                                        </div>
                                    </div>
                                    <div class="layui-form-item">
                                        <label class="layui-form-label">收货地址</label>
                                        <div class="layui-input-block">
                                            <input type="text" lay-verify="address" name="address" placeholder="请输入收货地址" autocomplete="off" class="layui-input">
                                        </div>
                                    </div>
                                    <div class="layui-form-item" style="display: none">
                                        <div class="layui-input-block">
                                            <input  type="text" name="headpicture">
                                        </div>
                                    </div>
                                    <div class="layui-form-item">
                                        <div class="layui-input-block">
                                            <button class="layui-btn" lay-submit lay-filter="sure">确定</button>
                                        </div>
                                    </div>
                                </form>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<footer>
    <p style="text-align: center">获取更多&nbsp:<a href="https://weibo.com/"><img src="/static/img/wb.png" alt=""></a><a
            href="" class="wx_hover"><img
            src="/static/img/dxy.png" alt="" class="codeleft"><img src="/static/img/wx.png" alt="" class="wxpicture"></a></p>
    <h3>联系我们&nbsp:000-000-000</h3>
</footer>
<!--表格操作-->
<script src="/static/js/swiper.min.js"></script>
<script src="/static/layui/layui.js"></script>
<script src="/static/js/mouseEvent.js"></script>
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<script>

    let loginout=document.getElementById("loginout");
    loginout.onclick=function(){
        sessionStorage.removeItem("userid");
        location.replace("index");
    }
    function GMTToStr(){
        var date = new Date();
        var Str=date.getFullYear() + '-' +
            (date.getMonth() + 1) + '-' +
            date.getDate() + ' ' +
            date.getHours() + ':' +
            date.getMinutes() + ':' +
            date.getSeconds()
        return Str
    }
    layui.use(['element','form','table','upload','layer'], function(){
        var element = layui.element,
            form=layui.form,
        upload = layui.upload,
        layer = layui.layer,
            $ = layui.jquery,
            table=layui.table;

        //我要提问
        let question = document.getElementById("my_question");
        question.onclick=function(){
            layer.open({
                type: 1
                ,title: false //不显示标题栏
                ,closeBtn: true
                ,area: '500px;'
                ,shade: 0.8
                ,id: 'LAY_layuipro' //设定一个id，防止重复弹出
                ,btn: ['提交','取消']
                ,btnAlign: 'c'
                ,moveType: 1 //拖拽模式，0或者1
                ,content: `
                    <div class="layui-card">
  <div class="layui-card-header">我要提问</div>
  <div class="layui-card-body">
    <form class="layui-form" lay-filter="quesForm">
    <div class="layui-form-item layui-form-text">
    <label class="layui-form-label" style="text-align: center">请输入问题</label>
    <div class="layui-input-block">
      <textarea name="question" placeholder="请输入内容" class="layui-textarea"></textarea>
    </div>
  </div>

  <div class="layui-form-item">
    <div class="layui-input-block" style="display: none">
      <input type="text" name="date" class="layui-input">
    </div>
  </div>
    </form>
  </div>
</div>
                    `
                ,yes: function(index, layero){
                    //do something
                    form.val("quesForm",{
                        date:GMTToStr()
                    });
                    axios.post("/api/ask/subquestion",{data:form.val("quesForm")}).then(res=>{
                        if(res.data.code==200){
                            layer.close(index); //如果设定了yes回调，需进行手工关闭
                            layer.alert("提交成功!请等待管理员回复!")
                        }else if(res.data.code==401){
                            layer.close(index);
                            layer.alert("请您先补全个人信息再来咨询!")
                        }else{
                            layer.close(index);
                            layer.alert("提交失败!")
                        }
                    });
                },
            });
        }

        //信息未读已读状态
        //
        let msg=document.getElementById("msg")
        axios.get("/api/ask/getanswer",{
            params:{userid:sessionStorage.getItem("userid")}
        }).then(res=>{
            if(res.data.data.state==2&&res.data.data.readystate==1){
                msg.innerHTML='<a data-method="notice" id="msg" style="font-size: 22px;font-weight: 600;">信息<span class="layui-badge-dot"></span></a>'
            }else if(res.data.data.answer!=="暂无回复"){
                msg.innerHTML=`<a data-method="notice" id="msg" style="font-size: 22px;font-weight: 600;">信息</a>`;
            }
        })

      //用户信息表获取数据
        let headP=document.getElementById("headP");
        axios.get("/api/user/personmsg",{params:{userid:sessionStorage.getItem("userid")}}).then(res=>{
            if(res.data.code==200){
                headP.src=res.data.data.headpicture;
                form.val("personMsg",{
                     "username":res.data.data.username,
                    "sex":res.data.data.sex,
                    "cardnumber":res.data.data.cardnumber,
                    "phone":res.data.data.phone,
                    "address":res.data.data.address,
                })
            }
        })
        //弹出层
        var active={
            notice: function(){
                //示范一个公告层
                layer.open({
                    type: 1
                    ,title: false //不显示标题栏
                    ,closeBtn: true
                    ,area: '500px;'
                    ,shade: 0.8
                    ,id: 'LAY_layuipro' //设定一个id，防止重复弹出
                    ,btn: ['还有问题']
                    ,btnAlign: 'c'
                    ,moveType: 1 //拖拽模式，0或者1
                    ,content: `
                    <div class="layui-card">
  <div class="layui-card-header">管理员回复</div>
  <div class="layui-card-body">
    <?php echo $data['answer']; ?>
  </div>
</div>
                    `
                    ,yes: function(index, layero){
                        //do something
                        layer.close(index); //如果设定了yes回调，需进行手工关闭
                    },
                    cancel: function(index, layero){
                        axios.post('/api/ask/doneready');
                        msg.innerHTML=`<a data-method="notice" id="msg" style="font-size: 22px;font-weight: 600;">信息</a>`;
                        layer.close(index);
                        return false;
                    }
                });
            }
        };

        $('#layerMsg a').on('click', function(){
            var othis = $(this), method = othis.data('method');
            active[method] ? active[method].call(this, othis) : '';
        });

        //执行上传实例
        var uploadInst = upload.render({
            elem: '#headpicture' //绑定元素
            ,url: '/api/uploads/upload' //上传接口
            ,done: function(res){
                //上传完毕回调
                layer.alert("上传成功!",function(index){
                    headP.src=res.data;
                    layer.close(index);
                    form.val("personMsg",{
                        "headpicture":res.data
                    });
                })
            }
            ,error: function(){
                //请求异常回调
                alert("出错")
            }
        });

        //表单验证
        form.verify({
            username: function(value, item){ //value：表单的值、item：表单的DOM对象
                if(value.length===0){
                    return '用户名不能为空!'
                }
                if(!new RegExp("^[\u4E00-\u9FA5]{2,4}$").test(value)){
                    return '用户名格式不正确';
                }
            },
            cardnumber: function(value, item){
                if(!new RegExp("^[1-9]\\d{5}(18|19|20|(3\\d))\\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$").test(value)){
                    return '身份证格式不正确';
                }
            },
            phone:function(value){
                if(!new RegExp("^1[3456789]\\d{9}$").test(value)){
                    return '手机号格式不正确';
                }
            },
            address:function(value){
                if(value.length<0){
                    return '请输入收货地址';
                }
            }
        });

        form.on('submit(sure)', function(data){
            console.log(data.field);
            axios.post("/api/user/update",{userid:sessionStorage.getItem('userid'),data:data.field}).then(res=>{
                   if(res.data.code==200){
                       layer.alert("提交成功")
                   }
            });
            return false;
        });
        form.render();
    });
</script>
</body>
</html>