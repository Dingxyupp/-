<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"C:\Users\dxy\Desktop\wbbg_admin\public/../application/index\view\pages\shop-car.html";i:1589703530;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        .layui-table-cell {height: 100px !important;line-height: 100px !important;}
    </style>
    <link rel="stylesheet" href="/static/css/index.css">
    <link rel="stylesheet" href="/static/css/swiper.min.css">
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <link rel="stylesheet" href="/static/css/shopcar.css">
</head>
<body>
<header>
    <img src="/static/img/ook.png" alt="" class="logo">
    <a class="hide_list1"><span class="header_serve" id="serve_serve">服务</span>
        <div class="list1">
            <li>
                <object><a href="<?php echo url('index/index/serve'); ?>" class="list_a_img"><img src="/static/img/flash.png" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p">焕新服务</p></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>#serve_example"><p class="list_p_p">刷新案例</p></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p_p">刷新服务Q&A</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>" class="list_a_img"><img src="/static/img/check.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>"><p class="list_p">墙面基检</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_wall"><p class="list_p_p">墙面问题</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_tool"><p class="list_p_p">检测工具</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_step"><p class="list_p_p">检测步骤</p></a></object>
            </li>
            <li>
                <object><a class="list_a_img" id="layui_alert_img"><img src="/static/img/serve_other.jpg" alt="" class="list_img"></a></object>
                <object><a href="" data-method="alert"  data-type="auto" id="layui_alert"><p class="list_p">其他服务</p></a></object>
            </li>
        </div>
    </a>
    <a href="<?php echo url('index/index/shop'); ?>"  class="hide_list2"><span class="header_shop" id="serve_shop">商城</span>
        <div class="list2">
            <li>
                <object><a href="<?php echo url('index/index/mallIn'); ?>" class="list_a_img"><img src="/static/img/paint_in.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p">室内漆</p></a></object>
                <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p_p">查看全部</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallOut'); ?>" class="list_a_img"><img src="/static/img/paint_out.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p">室外漆</p></a></object>
                <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p_p">查看更多</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallMu'); ?>" class="list_a_img"><img src="/static/img/paint_wood.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallMu'); ?>"><p class="list_p">木器漆</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallTu'); ?>" class="list_a_img"><img src="/static/img/paint_peijian.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallTu'); ?>"><p class="list_p">涂刷配件</p></a></object>
                <!--        <object><a href="serve.html"><p class="list_p_p">墙面底材</p></a></object>-->
                <!--        <object><a href="serve.html"><p class="list_p_p">工具</p></a></object>-->
            </li>
        </div></a>
    <a class="hide_list3"><span class="header_ask" id="serve_ask">咨询</span>
        <div class="list3">
            <li>
                <object><a href="<?php echo url('index/index/paintCalculation'); ?>" class="list_a_img"><img src="/static/img/kv0014_p.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/paintCalculation'); ?>"><p class="list_p">漆量计算</p></a></object>
            </li>
        </div></a>
    <a  class="hide_list4"><span class="header_about" id="serve_about">关于品牌</span>
        <div class="list4">
            <li>
                <object><a href="<?php echo url('index/index/aboutBrand'); ?>" class="list_a_img"><img src="/static/img/zeren1.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/aboutBrand'); ?>"><p class="list_p">关于品牌</p></a></object>
            </li>
        </div></a>
    <!--    <a href=""><span><i id="serve_search" class="layui-icon layui-icon-search header_a_search"></i></span></a>-->
    <a href="<?php echo url('index/index/shopCar'); ?>" id="judge_shopcar_href"><span><i id="serve_list" class="layui-icon layui-icon-cart-simple header_a_cart"></i></span></a>
    <a href="<?php echo url('index/index/personalCenter'); ?>" id="judge_personal_href"><span><i id="serve_user" class="layui-icon layui-icon-user header_a_user"></i></span></a>
</header>
<h2 class="shopping_list">购物清单
    <form class="layui-form layui-form-pane" lay-filter="price">
    <div class="layui-form-item" pane style="float: right">
        <label class="layui-form-label" style="text-align: center;color:#FF5722">总金额:</label>
        <div class="layui-input-block">
            <input type="text" name="totalPrice" value="0" class="layui-input" disabled style="width: 100px">
        </div>
    </div>
    </form>
</h2>

<!--表格-->
<div class="shop_car_main">
    <table id="shopCarTable" lay-filter="shopCar">
    </table>
</div>

<footer>
    <p style="text-align: center">获取更多&nbsp:<a href="https://weibo.com/"><img src="/static/img/wb.png" alt=""></a><a
            href="" class="wx_hover"><img
            src="/static/img/dxy.png" alt="" class="codeleft"><img src="/static/img/wx.png" alt="" class="wxpicture"></a></p>
    <h3>联系我们&nbsp:000-000-000</h3>
</footer>
<!--结算-->
<script type="text/html" id="payment">
    <div class="layui-btn-container">
        <button class="layui-btn layui-btn-sm" lay-event="payCheck">付款</button>
    </div>
</script>
<script type="text/html" id="barDemo">
    <div class="layui-btn-group">
        <button type="button" lay-submit class="layui-btn layui-btn-sm" lay-event="add">
            <i class="layui-icon">&#xe654;</i>
        </button>
        <button type="button" lay-submit class="layui-btn layui-btn-sm" lay-event="sub">
            <i class="layui-icon layui-icon-subtraction"></i>
        </button>
        <button type="button" lay-submit class="layui-btn layui-btn-sm  layui-btn-danger" lay-event="del" >
            <i class="layui-icon">&#xe640;</i>
        </button>
    </div>
</script>
<script type="text/html" id="goodsImg">
    <div><img src="{{ d.avatar }}" style="width: 30px; height: 30px;"></div>
</script>
<script src="/static/js/swiper.min.js"></script>
<script src="/static/layui/layui.js"></script>
<script src="/static/js/mouseEvent.js"></script>
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<script>
    function GMTToStr(){
        var date = new Date();
        var Str=date.getFullYear() + '-' +
            (date.getMonth() + 1) + '-' +
            date.getDate() + ' ' +
            date.getHours() + ':' +
            date.getMinutes() + ':' +
            date.getSeconds()
        return Str
    }
    let subtraction=document.getElementById("subtraction")
    layui.use(['layer',  'form','table'], function () {
        var layer = layui.layer,
            table =layui.table
            form = layui.form;
        table.render({
            id:"te",
            skin: 'nob',
            elem: '#shopCarTable'
            ,toolbar: '#payment' //开启头部工具栏，并为其绑定左侧模板
            ,page: { //支持传入 laypage 组件的所有参数（某些参数除外，如：jump/elem） - 详见文档
                // layout: ['limit', 'count', 'prev', 'page', 'next', 'skip'] //自定义分页布局
                limit:5
                ,limits:[5,10,15]
                ,groups: 1 //只显示 1 个连续页码
                ,first: false //不显示首页
                ,last: false //不显示尾页
            }
            ,url:'/api/scar/select'
            ,parseData: function(res){ //res 即为原始返回的数据
                return {
                    "code": res.code, //解析接口状态
                    "msg": res.msg, //解析提示文本
                    "count": res.count, //解析数据长度
                    "data": res.data //解析数据列表
                };
            }
            ,title: '用户数据表'
            ,cols: [[
                {type: 'checkbox', fixed: 'left'}
                ,{field:'picture',align:"center", title:'产品',templet: '<div><img src="{{ d.picture }}" style="width:70px; height:70px;"></div>', width:120,}
                ,{field:'goodsname',align:"center", title:'商品名', width:240, sort: false}
                ,{field:'color', align:"center",title:'颜色', width:240}
                ,{field:'count',align:"center", title:'数量', width:240, sort: true}
                ,{field:'price',align:"center", title:'金额', width:240,sort: true}
                ,{fixed: 'right',align:"center", title:'操作', toolbar: '#barDemo'}
            ]]
        });
        //结账事件
        table.on('toolbar(shopCar)', function(obj){
            var checkStatus = table.checkStatus(obj.config.id);//获取表格选中行数据，参数id
            let data=checkStatus.data;
            console.log(data);
            switch(obj.event){
                case 'payCheck':
                    //信息确认弹出层
                    if(data.length===0){
                       layer.alert('请选择要结算的物品!');
                   }else{
                       axios.get("/api/user/personmsg",{params:{userid:sessionStorage.getItem("userid")}}).then((res)=>{
                           if(res.data.code==200){
                               let data=res.data.data;
                               if(!data.headpicture&&!data.username&&!data.sex&&!data.phone&&!data. address&&!data.cardnumber){
                                   layer.alert("您的信息未完善，请先完善信息!");
                               }else{
                                   layer.open({
                                       type: 1
                                       ,title: "确认订单" //不显示标题栏
                                       ,closeBtn: false
                                       ,area: '300px;'
                                       ,shade: 0.8
                                       ,id: 'LAY_layuipro' //设定一个id，防止重复弹出
                                       ,btn: ['确定', '取消']
                                       ,btnAlign: 'c'
                                       ,moveType: 1 //拖拽模式，0或者1
                                       ,content: `<div style="padding: 10px; line-height: 22px; background-color: #393D49; color: #fff; font-weight: 300;">
<form class="layui-form" >
  <div class="layui-form-item">
    <label class="layui-form-label" style="text-align: center;padding: 9px 0px;width: 70px">收货人</label>
    <div class="layui-input-block" style="margin-left: 80px;">
      <input type="text" style="width:70%;" disabled name="username" value="${data.username}" class="layui-input">
    </div>
  </div>

  <div class="layui-form-item">
    <label class="layui-form-label" style="text-align: center;padding: 9px 0px;width: 70px">电话</label>
    <div class="layui-input-block" style="margin-left: 80px;">
      <input type="text" style="width:70%" disabled name="phone" value="${data.phone}"  class="layui-input">
    </div>
  </div>

  <div class="layui-form-item">
    <label class="layui-form-label" style="text-align: center;padding: 9px 0px;width: 70px">收货地址</label>
    <div class="layui-input-block" style="margin-left: 80px;">
      <input type="text" style="width:100%" disabled name="address" value="${data.address}"  class="layui-input">
    </div>
  </div>

  <div class="layui-form-item">
    <label class="layui-form-label" style="text-align: center;padding: 9px 0px;width: 70px">价格</label>
    <div class="layui-input-block" style="margin-left: 80px;">
      <input type="text" style="width:70%" disabled name="price" value="${form.val("price").totalPrice}" class="layui-input">
    </div>
  </div>
  </form>
</div>`
                                       ,success: function(layero){
                                           sessionStorage.setItem("paygoods",JSON.stringify(data))
                                       }
                                       ,yes:function(){
                                           carData.forEach(v=>{
                                               v.date=GMTToStr();
                                               v.userid="";
                                               v.nickname="";
                                               v.username="";
                                               v.phone="";
                                               v.address="";
                                               v.finishdate="";
                                               v.logistics="";
                                               v.commonets="";
                                           });
                                           axios.post("/api/order/adddata",{data:carData}).then(res=>{
                                                   sessionStorage.setItem("addtime",res.data.addtime)
                                           });
                                           location.replace("pay.html")
                                       }
                                   });
                               }
                           }
                       });
                   }
                    //弹出一个弹出层，用来确认用户，电话，收货地址是否正确，下边弹出金额，只有确认按钮
                    //点击确定关闭该弹出层，再打开一个新弹出层，里面是支付方式，选择支付方式，银行卡和密码支付，确认支付将数据添加进去，取消向订单数据库发送请求，将该订单加进去（默认就是未支付状态）。
                    //点击支付后将选中数据的paystate变为1，更新订单数据库。回调成功后弹出支付成功
                    break;
            };
        });

        //监听行工具事件
        table.on('tool(shopCar)', function(obj){
            var data = obj.data;
            if(obj.event === 'del'){
                layer.confirm('确定删除该商品？', function(index){
                    obj.del();
                    layer.close(index);
                    axios.post("/api/scar/delete",{shopcarid:data.shopcarid})
                });
            } else if(obj.event === 'sub'){
                if(data.count===1){return}
                obj.update({
                    price: (obj.data.price/obj.data.count)*(obj.data.count-1),
                    count: --obj.data.count
                });
                axios.post("/api/scar/countSub",{count:data.count,
                    shopcarid:data.shopcarid,goodsid:data.goodsid})
                //页面的count也变化
                //然后把obj.data发过去更新购物车数据库，在重新select一下，
            //    等下次打开购物车时，会把新数据渲染到购物车
            }else if(obj.event === 'add'){
                obj.update({
                    count: ++obj.data.count,
                    price: obj.data.count>1?(obj.data.price*obj.data.count)/(obj.data.count-1)+".00":(obj.data.price*obj.data.count)+".00"
                });
                axios.post("/api/scar/countadd",{count:data.count,
                    shopcarid:data.shopcarid,goodsid:data.goodsid})
            }
        });

        //监听check
        var totalData=0;
        var carData=[];
        table.on('checkbox(shopCar)', function(obj){

            var checkStatus = table.checkStatus('te')
                ,data = checkStatus.data;
            carData= checkStatus.data;
            data.forEach(v=>{
                totalData+=Number(v.price)
            });
            form.val("price",{
                totalPrice:totalData
            });
            sessionStorage.setItem("totalData",totalData);
            totalData=0;
        });
    });
</script>
</body>
</html>