<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"C:\Users\dxy\Desktop\wbbg_admin\public/../application/index\view\pages\login.html";i:1589078137;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">

    <title>登录页面</title>
    <!-- <link rel="icon" type="image/x-icon" href="favicon.ico"> -->
    <link href="iTunesArtwork@2x.png" sizes="114x114" rel="apple-touch-icon-precomposed">
    <link rel="stylesheet" type="text/css" href="/static/css/register.css">
    <link rel="stylesheet" type="text/css" href="/static/css/login.css">
    <link rel="stylesheet" href="/static/layui/css/layui.css">
</head>
<body>

<header class="aui-header">
    <div class="aui-header-box">
        <h1>
            <a href="index.html" class="aui-header-box-logo"></a>
        </h1>
    </div>
</header>

<section class="aui-content">
    <div class="aui-content-box clearfix">
        <div class="aui-content-box-fl">
            <div class="aui-form-header">
                <div class="aui-form-header-item on">密码登录</div>
                <span class="aui-form-header-san"></span>
            </div>
            <div class="aui-form-content">
                <div class="aui-form-content-item">
                    <form class="layui-form"  lay-filter="userMessage">
                        <div class="aui-form-list">
                            <input type="text" lay-verify="account" class="aui-input" name="account" placeholder="请输入用户名" >
                        </div>

                        <div class="aui-form-list">
                            <input type="password" lay-verify="pass" class="aui-input" name="pass" placeholder="请输入密码">
                        </div>

                        <div class="layui-form-item">
                        <div class="aui-form-btn layui-input-block" style="margin-left: 0;">
                            <button type="submit" class="layui-btn aui-btn" lay-submit  lay-filter="demo1">登&nbsp录</button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="aui-content-box-fr">
            <div class="aui-content-box-text">
                <h3>还没有帐号:</h3>
                <a href="register.html" class="aui-ll-link">立即注册</a>
                <h3>使用第三方帐号直接登录:</h3>
                <ul class="aui-content-box-text-link clearfix">
                    <li><a href="#" class="aui-icon-sina"   title="使用新浪微博帐号登录"></a></li>
                    <li><a href="#" class="aui-icon-wechat" title="使用微信帐号登录"></a></li>
                    <li><a href="#" class="aui-icon-qq"     title="使用腾讯QQ帐号登录"></a></li>
                    <li><a href="#" class="aui-icon-baidu"  title="使用百度帐号登录"></a></li>
                </ul>
            </div>
        </div>
    </div>
</section>

<script type="text/javascript" src="/static/js/jquery.min.js"></script>
<script src="/static/layui/layui.js"></script>
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<script type="text/javascript">
    $(function(){

        /*tab标签切换*/
        function tabs(tabTit,on,tabCon){
            $(tabCon).each(function(){
                $(this).children().eq(0).show();

            });
            $(tabTit).each(function(){
                $(this).children().eq(0).addClass(on);
            });
            $(tabTit).children().click(function(){
                $(this).addClass(on).siblings().removeClass(on);
                var index = $(tabTit).children().index(this);
                $(tabCon).children().eq(index).show().siblings().hide();
            });
        }
        tabs(".aui-form-header","on",".aui-form-content");

    })
    
    layui.use(['form', 'element', 'laypage', 'layer'], function () {
    var element = layui.element,
            layer = layui.layer,
            $ = layui.jquery,
            form = layui.form;
            form.verify({
  account: function(value, item){ //value：表单的值、item：表单的DOM对象
    if(value.length===0){
        return '用户名不能为空!'
    }
    // if(!new RegExp("^[a-zA-Z0-9_\u4e00-\u9fa5\\s·]+$").test(value)){
    //   return '用户名不能有特殊字符';
    // }
    if(value.length<5){
        return '用户名长度不得低于5'
    }
    if(/^\d+\d+\d$/.test(value)){
      return '用户名不能全为数字';
    }
  },
  pass: function(value, item){ 
    if(!new RegExp("(?=.*([a-zA-Z].*))(?=.*[0-9].*)[a-zA-Z0-9-*/+.~!@#$%^&*()]{6,20}$").test(value)){
      return '密码至少6个字符，必须有数字和字母,字符可以有';
    }
  }
});     
            form.on('submit(demo1)', function(data){
                var loginMes = form.val("userMessage");
                axios.post('/api/admin/weblogin',{loginMes:loginMes}).then((res)=>{
                    if(res.data.code===200){
                        sessionStorage.setItem("userid",res.data.userid)
                        location.assign("index.html");
                    }
                    if(res.data.code===401){
                        layer.alert("不存在该用户，请您先注册")
                    }
                    if(res.data.code===402){
                        layer.alert("密码错误,请重新输入密码",function (index) {
                            form.val("userMessage",{
                                "pass":""
                            })
                            layer.close(index)
                        })
                    }
                })
                //回调将userid加到sessionStorage里，然后跳转到index页面
                 return false;
  });
            })
</script>

</body>
</html>