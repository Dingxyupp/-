<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"C:\Users\dxy\Desktop\wbbg_admin\public/../application/index\view\pages\register.html";i:1589078296;}*/ ?>
﻿<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
 
	<title>注册页面</title>
	<link href="iTunesArtwork@2x.png" sizes="114x114" rel="apple-touch-icon-precomposed">
	<link rel="stylesheet" type="text/css" href="/static/css/login.css">
	<link rel="stylesheet" type="text/css" href="/static/css/register.css">
	<link rel="stylesheet" href="/static/layui/css/layui.css">
</head>
<body>

	<header class="aui-header">
		<div class="aui-header-box">
			<h1>
				<a href="index.html" class="aui-header-box-logo"></a>
			</h1>
		</div>
	</header>

	<section class="aui-content">
		<div class="aui-content-box clearfix">
			<div class="aui-content-box-fl">
				<h2>注册账号</h2>

				<div class="aui-form-content">

					<div class="aui-form-content-item" style="display:block">
						<form class="layui-form" lay-filter="regMessage">
							<div class="aui-form-list">
								<input type="text" lay-verify="account" class="aui-input" name="account" placeholder="请输入用户名" >
							</div>
							<div class="aui-form-list">
								<input type="password" lay-verify="pass" class="aui-input" name="pass" id="pass" placeholder="请输入密码">
							</div>
							<div class="aui-form-list">
								<input type="password" lay-verify="repass"  class="aui-input" value="" name="repass" placeholder="再次输入密码">
							</div>
							<div class="layui-form-item">
							<div class="aui-form-btn layui-input-block" style="margin-left: 0;">
								<button type="submit" class="layui-btn aui-btn" lay-submit="" lay-filter="demo1">注&nbsp册</button>
							</div>
						    </div>
							<div class="aui-form-ty">
								注册代表你已同意 <a href="#" style="color: #ed4242">「用户协议」</a>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="aui-content-box-fr">
				<div class="aui-content-box-text">
					<h3>已有帐号:</h3>
					<a href="login.html" class="aui-ll-link">直接登录</a>
					<h3>使用第三方帐号直接登录:</h3>
					<ul class="aui-content-box-text-link clearfix">
						<li><a href="#" class="aui-icon-sina"   title="使用新浪微博帐号登录"></a></li>
						<li><a href="#" class="aui-icon-wechat" title="使用微信帐号登录"></a></li>
						<li><a href="#" class="aui-icon-qq"     title="使用腾讯QQ帐号登录"></a></li>
						<li><a href="#" class="aui-icon-baidu"  title="使用百度帐号登录"></a></li>
					</ul>
				</div>
			</div>
		</div>
	</section>

	<script type="text/javascript" src="/static/js/jquery.min.js"></script>
	<script src="/static/layui/layui.js"></script>
	<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
	<script type="text/javascript">
        $(function(){

			/*tab标签切换*/
            function tabs(tabTit,on,tabCon){
                $(tabCon).each(function(){
                    $(this).children().eq(0).show();

                });
                $(tabTit).each(function(){
                    $(this).children().eq(0).addClass(on);
                });
                $(tabTit).children().click(function(){
                    $(this).addClass(on).siblings().removeClass(on);
                    var index = $(tabTit).children().index(this);
                    $(tabCon).children().eq(index).show().siblings().hide();
                });
            }
            tabs(".aui-form-header","on",".aui-form-content");

        })
	    layui.use(['form', 'element', 'laypage', 'layer'], function () {
    var element = layui.element,
			layer = layui.layer,
			$ = layui.$,
            form = layui.form;
            form.verify({
  account: function(value, item){ //value：表单的值、item：表单的DOM对象
    if(value.length===0){
        return '用户名不能为空!'
    }
    // if(!new RegExp("^[a-zA-Z0-9_\u4e00-\u9fa5\\s·]+$").test(value)){
    //   return '用户名不能有特殊字符';
    // }
    if(value.length<5){
        return '用户名长度不得低于5'
    }
    if(/^\d+\d+\d$/.test(value)){
      return '用户名不能全为数字';
    }
  },
  pass: function(value, item){ 
    if(!new RegExp("(?=.*([a-zA-Z].*))(?=.*[0-9].*)[a-zA-Z0-9-*/+.~!@#$%^&*()]{6,20}$").test(value)){
      return '密码至少6个字符，必须有数字和字母,字符可以有';
    }
  },
  repass:function (value){
	  if(value.length==0){
		  return '请确认密码'
	  }
	  if($('input[id=pass]').val() !== value){
		  return '两次密码不一致'
	  }
  }
});     
            form.on('submit(demo1)', function(data){
				//拿到data.field之发起请求，将该条数据加入到数据库里  regMessage
				let registerMes=form.val("regMessage");
				axios.post('/api/admin/webregister',{registerMes:registerMes}).then((res)=>{
					if(res.data.code===200){
						layer.alert("注册成功,请您登陆");
						location.assign("login.html");
					}
					if(res.data.code===400){
						layer.alert("该用户名已经存在!请您重新输入用户名!",function (index) {
							form.val("regMessage",{
								"account":""
							})
							layer.close(index)
						});
					}
				});
                 return false;
  });
            })
	</script>

</body>
</html>