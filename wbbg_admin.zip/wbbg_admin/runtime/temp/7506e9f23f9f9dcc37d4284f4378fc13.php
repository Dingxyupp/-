<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"C:\Users\dxy\Desktop\wbbg_admin\public/../application/index\view\pages\pay.html";i:1589469012;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="/static/js/swiper.min.js"></script>
    <link rel="stylesheet" href="/static/css/index.css">
    <link rel="stylesheet" href="/static/css/swiper.min.css">
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <link rel="stylesheet" href="/static/css/peosoncenter.css">
</head>
<body>
<header>
    <img src="/static/img/ook.png" alt="" class="logo">
    <a class="hide_list1"><span class="header_serve" id="serve_serve">服务</span>
        <div class="list1">
            <li>
                <object><a href="<?php echo url('index/index/serve'); ?>" class="list_a_img"><img src="/static/img/flash.png" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p">焕新服务</p></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>#serve_example"><p class="list_p_p">刷新案例</p></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p_p">刷新服务Q&A</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>" class="list_a_img"><img src="/static/img/check.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>"><p class="list_p">墙面基检</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_wall"><p class="list_p_p">墙面问题</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_tool"><p class="list_p_p">检测工具</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_step"><p class="list_p_p">检测步骤</p></a></object>
            </li>
            <li>
                <object><a class="list_a_img" id="layui_alert_img"><img src="/static/img/serve_other.jpg" alt="" class="list_img"></a></object>
                <object><a href="" data-method="alert"  data-type="auto" id="layui_alert"><p class="list_p">其他服务</p></a></object>
            </li>
        </div>
    </a>
    <a href="<?php echo url('index/index/shop'); ?>"  class="hide_list2"><span class="header_shop" id="serve_shop">商城</span>
        <div class="list2">
            <li>
                <object><a href="<?php echo url('index/index/mallIn'); ?>" class="list_a_img"><img src="/static/img/paint_in.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p">室内漆</p></a></object>
                <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p_p">查看全部</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallOut'); ?>" class="list_a_img"><img src="/static/img/paint_out.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p">室外漆</p></a></object>
                <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p_p">查看更多</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallMu'); ?>" class="list_a_img"><img src="/static/img/paint_wood.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallMu'); ?>"><p class="list_p">木器漆</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallTu'); ?>" class="list_a_img"><img src="/static/img/paint_peijian.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallTu'); ?>"><p class="list_p">涂刷配件</p></a></object>
            </li>
        </div></a>
    <a class="hide_list3"><span class="header_ask" id="serve_ask">咨询</span>
        <div class="list3">
            <li>
                <object><a href="<?php echo url('index/index/paintCalculation'); ?>" class="list_a_img"><img src="/static/img/kv0014_p.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/paintCalculation'); ?>"><p class="list_p">漆量计算</p></a></object>
            </li>
        </div></a>
    <a  class="hide_list4"><span class="header_about" id="serve_about">关于品牌</span>
        <div class="list4">
            <li>
                <object><a href="<?php echo url('index/index/aboutBrand'); ?>" class="list_a_img"><img src="/static/img/zeren1.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/aboutBrand'); ?>"><p class="list_p">关于品牌</p></a></object>
            </li>
        </div></a>
    <!--    <a href=""><span><i id="serve_search" class="layui-icon layui-icon-search header_a_search"></i></span></a>-->
    <a href="<?php echo url('index/index/shopCar'); ?>" id="judge_shopcar_href"><span><i id="serve_list" class="layui-icon layui-icon-cart-simple header_a_cart"></i></span></a>
    <a href="<?php echo url('index/index/personalCenter'); ?>" id="judge_personal_href"><span><i id="serve_user" class="layui-icon layui-icon-user header_a_user"></i></span></a>
</header>
<div style="width:100%;height:180px;margin-top: 96px;background: url(/public/static/img/house.jpg) no-repeat center"></div>
<div style="height:auto;margin-top:40px;background: url(https://www.dulux.com.cn/profiles/flourish/themes/custom/flourish_rem/images/vertical-shade.jpg);">
    <div style="height:100%;width:50%;margin: 0 auto;">
        <div class="layui-tab layui-tab-brief" lay-filter="docDemoTabBrief">
            <ul class="layui-tab-title">
                <li class="layui-this">银行卡支付</li>
                <li>微信支付</li>
            </ul>
            <div class="layui-tab-content">
                <div class="layui-tab-item layui-show">
                    <form class="layui-form layui-form-pane">
                        <div class="layui-form-item" pane>
                            <label class="layui-form-label">卡号</label>
                            <div class="layui-input-block">
                                <input type="text" name="bandcardnumber" lay-verify="bandcardnumber" placeholder="请输入银行卡号" class="layui-input">
                            </div>
                        </div>

                        <div class="layui-form-item" pane>
                            <label class="layui-form-label">密码</label>
                            <div class="layui-input-block">
                                <input type="password" name="bandcardpass" lay-verify="bandcardpass" placeholder="请输入银行卡号" class="layui-input">
                            </div>
                        </div>

                        <div class="layui-form-item" pane>
                            <div class="layui-input-block" style="margin-left: 0px;text-align: center;">
                                <button type="submit" id="money" class="layui-btn" lay-submit lay-filter="paySub"></button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="layui-tab-item">
                    <p style="text-align: center;margin-bottom: 10px">请扫微信二维码完成支付</p>
                        <img src="/static/img/dxy.png" alt="" style="margin:0 auto;text-align:center;display: block;width:150px;height:150px">
                </div>
            </div>
        </div>
    </div>
</div>
<footer>
    <p style="text-align: center">获取更多&nbsp:<a href="https://weibo.com/"><img src="/static/img/wb.png" alt=""></a><a
            href="" class="wx_hover"><img
            src="/static/img/dxy.png" alt="" class="codeleft"><img src="/static/img/wx.png" alt="" class="wxpicture"></a></p>
    <h3>联系我们&nbsp:000-000-000</h3>
</footer>
<script src="/static/layui/layui.js"></script>
<script src="/static/js/mouseEvent.js"></script>
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<script>
    //拦截个人中心
    let judge_personal_href=document.getElementById("judge_personal_href");
    judge_personal_href.addEventListener("click",function (e) {
        e.preventDefault();
        if(!sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/login'); ?>")
        }else if(sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/personalCenter'); ?>")
        }
    });
    //拦截购物车
    let judge_shopcar_href=document.getElementById("judge_shopcar_href");
    judge_shopcar_href.addEventListener("click",function (e) {
        e.preventDefault();
        if(!sessionStorage.getItem("userid")){
            e.preventDefault();
            window.location.assign("<?php echo url('index/index/login'); ?>")
        }else if(sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/shopCar'); ?>")
        }
    });
    //支付xxx元
    let money=document.getElementById("money");
    money.innerText="支付"+sessionStorage.getItem("totalData")+"元"
    layui.use(['form', 'element', 'laypage', 'layer'], function () {
        var element = layui.element,
            laypage = layui.laypage,
            layer = layui.layer,
            form = layui.form;

    //    表单验证
        form.verify({
            bandcardnumber: function(value, item){ //value：表单的值、item：表单的DOM对象
                if(value.length===0){
                    return '请输入银行卡号'
                }
                if(!new RegExp("^([1-9]{1})(\\d{14}|\\d{18})$").test(value)){
                    return '请输入正确的银行卡号';
                }
            },
            bandcardpass: function(value, item){ //value：表单的值、item：表单的DOM对象
            if(value.length===0){
                return '请输入密码'
            }
            if(!new RegExp("^\\d{6}$").test(value)){
                return '密码为六位数字';
            }
        },
        });

        //表单提交
        form.on('submit(paySub)', function(data){
            // 付款后，数据传到后台，解析加入到订单数据库里，paystate更新为1。弹出付款成功提示，确定按钮会自动返回到购物车界面
            if(data.field.bandcardnumber=="184065860191111"&&data.field.bandcardpass=="123456"){
                var index = layer.load();
                //将paygoods数组拿到,将其用ajax传过去，回掉显示成功，关闭加载
                axios.post("/api/order/changepaystate",{date:sessionStorage.getItem("addtime")}).then(res=>{
                  setTimeout(function(){
                      if(res.data.code===200){
                          layer.close(index);
                          layer.alert("付款成功!")
                      }
                  },1000)
                })
            }else if(data.field.bandcardnumber!="184065860191111"){
                layer.alert('卡号不存在!');
            }else if(data.field.bandcardpass!="123456"){
                layer.alert('密码不正确!');
            }
            return false; //阻止表单跳转。如果需要表单跳转，去掉这段即可。
        });
    })
</script>
</body>
</html>