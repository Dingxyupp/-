<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"C:\Users\dxy\Desktop\wbbg_admin\public/../application/index\view\pages\index.html";i:1589473356;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Title</title>
  <link rel="stylesheet" href="/static/css/index.css">
  <link rel="stylesheet" href="/static/css/swiper.min.css">
  <link rel="stylesheet" href="/static/layui/css/layui.css">
</head>
<body>
<header>
  <img src="/static/img/ook.png" alt="" class="logo">
  <a  class="hide_list1"><span class="header_serve">服务</span>
    <div class="list1">
      <li>
        <object><a href="<?php echo url('index/index/serve'); ?>" class="list_a_img"><img src="/static/img/flash.png" alt="" class="list_img"></a></object>
        <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p">焕新服务</p></a></object>
        <object><a href="<?php echo url('index/index/serve'); ?>#serve_example"><p class="list_p_p">刷新案例</p></a></object>
        <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p_p">刷新服务Q&A</p></a></object>
      </li>
      <li>
        <object><a href="<?php echo url('index/index/wallCheck'); ?>" class="list_a_img"><img src="/static/img/check.jpg" alt="" class="list_img"></a></object>
        <object><a href="<?php echo url('index/index/wallCheck'); ?>"><p class="list_p">墙面基检</p></a></object>
        <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_wall"><p class="list_p_p">墙面问题</p></a></object>
        <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_tool"><p class="list_p_p">检测工具</p></a></object>
        <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_step"><p class="list_p_p">检测步骤</p></a></object>
      </li>
      <li>
        <object><a class="list_a_img" id="layui_alert_img"><img src="/static/img/serve_other.jpg" alt="" class="list_img"></a></object>
        <object><a href="" data-method="alert"  data-type="auto" id="layui_alert"><p class="list_p">其他服务</p></a></object>
      </li>
    </div>
  </a>
  <a href="<?php echo url('index/index/shop'); ?>" class="hide_list2"><span class="header_shop">商城</span>
    <div class="list2">
      <li>
        <object><a href="<?php echo url('index/index/mallIn'); ?>" class="list_a_img"><img src="/static/img/paint_in.jpg" alt="" class="list_img"></a></object>
        <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p">室内漆</p></a></object>
        <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p_p">查看全部</p></a></object>
      </li>
      <li>
        <object><a href="<?php echo url('index/index/mallOut'); ?>" class="list_a_img"><img src="/static/img/paint_out.jpg" alt="" class="list_img"></a></object>
        <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p">室外漆</p></a></object>
        <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p_p">查看更多</p></a></object>
      </li>
      <li>
        <object><a href="<?php echo url('index/index/mallMu'); ?>" class="list_a_img"><img src="/static/img/paint_wood.jpg" alt="" class="list_img"></a></object>
        <object><a href="<?php echo url('index/index/mallMu'); ?>"><p class="list_p">木器漆</p></a></object>
      </li>
      <li>
        <object><a href="<?php echo url('index/index/mallTu'); ?>" class="list_a_img"><img src="/static/img/paint_peijian.jpg" alt="" class="list_img"></a></object>
        <object><a href="<?php echo url('index/index/mallTu'); ?>"><p class="list_p">涂刷配件</p></a></object>
<!--        <object><a href="serve.html"><p class="list_p_p">墙面底材</p></a></object>-->
<!--        <object><a href="serve.html"><p class="list_p_p">工具</p></a></object>-->
      </li>
    </div></a>
  <a  class="hide_list3"><span class="header_ask">咨询</span>
    <div class="list3">
      <li>
        <object><a href="<?php echo url('index/index/paintCalculation'); ?>" class="list_a_img"><img src="/static/img/kv0014_p.jpg" alt="" class="list_img"></a></object>
        <object><a href="<?php echo url('index/index/paintCalculation'); ?>"><p class="list_p">漆量计算</p></a></object>
      </li>
      <li>
        <object><a class="list_a_img" id="my_question"><img src="/static/img/star.png" alt="" class="list_img"></a></object>
        <object><a ><p class="list_p">我要提问</p></a></object>
      </li>
    </div></a>
  <a  class="hide_list4"><span class="header_about">关于品牌</span>
    <div class="list4">
      <li>
        <object><a href="<?php echo url('index/index/aboutBrand'); ?>" class="list_a_img"><img src="/static/img/zeren1.jpg" alt="" class="list_img"></a></object>
        <object><a href="<?php echo url('index/index/aboutBrand'); ?>"><p class="list_p">关于品牌</p></a></object>
      </li>
    </div></a>
  <a href="<?php echo url('index/index/shopCar'); ?>" id="judge_shopcar_href"><span><i class="layui-icon layui-icon-cart-simple header_a_cart"></i></span></a>
  <a href="<?php echo url('index/index/personalCenter'); ?>" id="judge_personal_href"><span><i class="layui-icon layui-icon-user header_a_user"></i></span></a>
</header>
<!--swiper-->
<div class="swiper-container">
  <div class="swiper-wrapper">
    <div class="swiper-slide"><img src="/static/img/demo.jpg" alt="" class="swiper_img1"></div>
    <div class="swiper-slide"><img src="/static/img/demo2.jpg" alt="" class="swiper_img2"></div>
    <div class="swiper-slide"><img src="/static/img/demo3.jpg" alt="" class="swiper_img3"></div>
  </div>
  <!-- 如果需要导航按钮 -->
<!--  <div class="swiper-button-prev"></div>-->
<!--  <div class="swiper-button-next"></div>-->
</div>
<div class="main">
  <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
  <li>
    <a href="content.html"><img src="<?php echo $v['detail']; ?>" alt=""></a>
    <div class="main_content">
      <h2 style="text-align: center;margin-top: 80px;"><?php echo $v['title']; ?></h2>
      <p><?php echo $v['interview']; ?></p>
      <ul ><a href="content.html" class="href">阅读更多</a></ul>
    </div>
  </li>
  <?php endforeach; endif; else: echo "" ;endif; ?>
</div>
<!--footer-->
<footer>
  <p style="text-align: center">获取更多&nbsp:<a href="https://weibo.com/"><img src="/static/img/wb.png" alt=""></a><a
          href="" class="wx_hover"><img
          src="/static/img/dxy.png" alt="" class="codeleft"><img src="/static/img/wx.png" alt="" class="wxpicture"></a></p>
  <h3>联系我们&nbsp:000-000-000</h3>
</footer>
<script src="/static/js/swiper.min.js"></script>
<script src="/static/layui/layui.js"></script>
<script src="/static/js/mouseEvent.js"></script>
<script>
  let layui_alert=document.getElementById("layui_alert");
  //阻止该标签默认事件传播
  layui_alert.onclick=function(e){
    e.preventDefault();
  };
//拦截个人中心
  let judge_personal_href=document.getElementById("judge_personal_href");
  judge_personal_href.addEventListener("click",function (e) {
    e.preventDefault();
    if(!sessionStorage.getItem("userid")){
      window.location.assign("<?php echo url('index/index/login'); ?>")
    }else if(sessionStorage.getItem("userid")){
      window.location.assign("<?php echo url('index/index/personalCenter'); ?>")
    }
  });
//拦截购物车
  let judge_shopcar_href=document.getElementById("judge_shopcar_href");
  judge_shopcar_href.addEventListener("click",function (e) {
    e.preventDefault();
    if(!sessionStorage.getItem("userid")){
      e.preventDefault();
      location.assign("<?php echo url('index/index/login'); ?>")
    }else if(sessionStorage.getItem("userid")){
     location.assign("<?php echo url('index/index/shopCar'); ?>")
    }
  });

  layui.use(['form', 'element', 'laypage', 'layer'], function () {
    var element = layui.element,
            laypage = layui.laypage,
            $ = layui.jquery,
            layer = layui.layer,
            form = layui.form;

    //我要提问
    let question = document.getElementById("my_question");
    question.onclick=function(){
      layer.open({
        type: 1
        ,title: false //不显示标题栏
        ,closeBtn: true
        ,area: '500px;'
        ,shade: 0.8
        ,id: 'LAY_layuipro' //设定一个id，防止重复弹出
        ,btn: ['提交','取消']
        ,btnAlign: 'c'
        ,moveType: 1 //拖拽模式，0或者1
        ,content: `
        <div class="layui-card">
          <div class="layui-card-header">我要提问</div>
          <div class="layui-card-body">
            <form class="layui-form" lay-filter="quesForm">
              <div class="layui-form-item layui-form-text">
                <label class="layui-form-label" style="text-align: center">请输入问题</label>
                <div class="layui-input-block">
                  <textarea name="question" placeholder="请输入内容" class="layui-textarea"></textarea>
                </div>
              </div>

              <div class="layui-form-item">
                <div class="layui-input-block" style="display: none">
                  <input type="text" name="date" class="layui-input">
                </div>
              </div>
            </form>
          </div>
        </div>
        `
        ,yes: function(index, layero){
          //do something
          form.val("quesForm",{
            date:GMTToStr()
          });
          axios.post("/api/ask/subquestion",{data:form.val("quesForm")}).then(res=>{
            if(res.data.code==200){
              layer.close(index); //如果设定了yes回调，需进行手工关闭
              layer.alert("提交成功!请等待管理员回复!")
            }else if(res.data.code==401){
              layer.close(index);
              layer.alert("请您先补全个人信息再来咨询!")
            }else{
              layer.close(index);
              layer.alert("提交失败!")
            }
          });
        },
      });
    }

       var active={
         alert: function(othis){
           var type = othis.data('type')
           //示范一个公告层
           layer.open({
             type: 1
             ,title:'提示'
             ,offset: type //具体配置参考：http://www.layui.com/doc/modules/layer.html#offset
             ,id: 'layerDemo'+type //防止重复弹出
             ,content: '<div style="padding: 15px 120px;">敬请期待</div>'
             ,btn: '好的'
             ,anim:5
             , time: 2000//2s后自动关闭
             ,area: ['300px', '150px']
             ,btnAlign: 'c' //按钮居中
             ,shade: 0 //不显示遮罩
             ,yes: function(){
               layer.closeAll();
             }
           });
         }
       }
    $('#layui_alert').on('click', function(){
      var othis = $(this), method = othis.data('method');
      active[method] ? active[method].call(this, othis) : '';
    });
  })
</script>
</body>
</html>