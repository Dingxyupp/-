<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"C:\Users\dxy\Desktop\wbbg_admin\public/../application/index\view\pages\logmange.html";i:1589507840;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <title>Title</title>
    <style>
        .lm_main{
            padding:70px 60px;
            margin-top: 96px;
            width:auto;
            height:500px;
            background: url(https://www.dulux.com.cn/profiles/flourish/themes/custom/flourish_rem/images/vertical-shade.jpg);
        }
    </style>
    <link rel="stylesheet" href="/static/css/index.css">
    <link rel="stylesheet" href="/static/css/swiper.min.css">
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <!--    <link rel="stylesheet" href="/static/css/shop.css">-->
    <link rel="stylesheet" href="/static/css/peosoncenter.css">
</head>
<body>
<header>
    <img src="/static/img/ook.png" alt="" class="logo">
    <a class="hide_list1"><span class="header_serve" id="serve_serve">服务</span>
        <div class="list1">
            <li>
                <object><a href="<?php echo url('index/index/serve'); ?>" class="list_a_img"><img src="/static/img/flash.png" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p">焕新服务</p></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>#serve_example"><p class="list_p_p">刷新案例</p></a></object>
                <object><a href="<?php echo url('index/index/serve'); ?>"><p class="list_p_p">刷新服务Q&A</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>" class="list_a_img"><img src="/static/img/check.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>"><p class="list_p">墙面基检</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_wall"><p class="list_p_p">墙面问题</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_tool"><p class="list_p_p">检测工具</p></a></object>
                <object><a href="<?php echo url('index/index/wallCheck'); ?>#wc_step"><p class="list_p_p">检测步骤</p></a></object>
            </li>
            <li>
                <object><a class="list_a_img" id="layui_alert_img"><img src="/static/img/serve_other.jpg" alt="" class="list_img"></a></object>
                <object><a href="" data-method="alert"  data-type="auto" id="layui_alert"><p class="list_p">其他服务</p></a></object>
            </li>
        </div>
    </a>
    <a href="<?php echo url('index/index/shop'); ?>"  class="hide_list2"><span class="header_shop" id="serve_shop">商城</span>
        <div class="list2">
            <li>
                <object><a href="<?php echo url('index/index/mallIn'); ?>" class="list_a_img"><img src="/static/img/paint_in.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p">室内漆</p></a></object>
                <object><a href="<?php echo url('index/index/mallIn'); ?>"><p class="list_p_p">查看全部</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallOut'); ?>" class="list_a_img"><img src="/static/img/paint_out.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p">室外漆</p></a></object>
                <object><a href="<?php echo url('index/index/mallOut'); ?>"><p class="list_p_p">查看更多</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallMu'); ?>" class="list_a_img"><img src="/static/img/paint_wood.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallMu'); ?>"><p class="list_p">木器漆</p></a></object>
            </li>
            <li>
                <object><a href="<?php echo url('index/index/mallTu'); ?>" class="list_a_img"><img src="/static/img/paint_peijian.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/mallTu'); ?>"><p class="list_p">涂刷配件</p></a></object>
                <!--        <object><a href="serve.html"><p class="list_p_p">墙面底材</p></a></object>-->
                <!--        <object><a href="serve.html"><p class="list_p_p">工具</p></a></object>-->
            </li>
        </div></a>
    <a class="hide_list3"><span class="header_ask" id="serve_ask">咨询</span>
        <div class="list3">
            <li>
                <object><a href="<?php echo url('index/index/paintCalculation'); ?>" class="list_a_img"><img src="/static/img/kv0014_p.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/paintCalculation'); ?>"><p class="list_p">漆量计算</p></a></object>
            </li>
        </div></a>
    <a  class="hide_list4"><span class="header_about" id="serve_about">关于品牌</span>
        <div class="list4">
            <li>
                <object><a href="<?php echo url('index/index/aboutBrand'); ?>" class="list_a_img"><img src="/static/img/zeren1.jpg" alt="" class="list_img"></a></object>
                <object><a href="<?php echo url('index/index/aboutBrand'); ?>"><p class="list_p">关于品牌</p></a></object>
            </li>
        </div></a>
    <!--    <a href=""><span><i id="serve_search" class="layui-icon layui-icon-search header_a_search"></i></span></a>-->
    <a href="<?php echo url('index/index/shopCar'); ?>" id="judge_shopcar_href"><span><i id="serve_list" class="layui-icon layui-icon-cart-simple header_a_cart"></i></span></a>
    <a href="<?php echo url('index/index/personalCenter'); ?>" id="judge_personal_href"><span><i id="serve_user" class="layui-icon layui-icon-user header_a_user"></i></span></a>
</header>
<div class="lm_main">
    <div class="layui-tab layui-tab-brief" lay-filter="docDemoTabBrief">
        <ul class="layui-tab-title">
            <li data-status="" class="layui-this">已发货</li>
            <li data-status="1">已完成</li>
        </ul>
        <div class="layui-tab-content">
            <div class="layui-tab-item layui-show" style="display: none">
                <table class="layui-table" lay-filter="logmange" lay-even lay-skin="nob" lay-size="lg" id="da_table" lay-data="{page:{limit:5},url:'/api/order/looklog'}">
                    <thead>
                    <tr>
                        <th lay-data="{field:'orderid', width:80}">订单号</th>
                        <th lay-data="{field:'goodsname', width:400}">商品名</th>
                        <th lay-data="{field:'date', width:150}">下单时间</th>
                        <th lay-data="{field:'username', width:80}">收货人</th>
                        <th lay-data="{field:'money', width:80}">金额</th>
                        <th lay-data="{field:'address', width:200}">收货地址</th>
                        <th lay-data="{field:'logistics'}">当前位置</th>
                        <th lay-data="{fixed: 'right', align:'center', toolbar: '#barDemo'}"></th>
                    </tr>
                    </thead>
                </table>
            </div>
            <div class="layui-tab-item">
            <table class="layui-table" lay-filter="logmange" lay-even lay-skin="nob" lay-size="lg" id="da_dotable" lay-data="{id: 'idTest',page:{limit:5},url:'/api/order/makesure'}">
                <thead>
                <tr>
                    <th lay-data="{field:'orderid', width:80}">订单号</th>
                    <th lay-data="{field:'goodsname', width:400}">商品名</th>
                    <th lay-data="{field:'date', width:150}">下单时间</th>
                    <th lay-data="{field:'username', width:80}">收货人</th>
                    <th lay-data="{field:'money', width:80}">金额</th>
                    <th lay-data="{field:'address', width:200}">收货地址</th>
                    <th lay-data="{field:'logistics'}">当前位置</th>
                    <th lay-data="{fixed: 'right', align:'center', field:'state'}">状态</th>
                </tr>
                </thead>
            </table>
            </div>
        </div>
    </div>
</div>
<footer>
    <p style="text-align: center">获取更多&nbsp:<a href="https://weibo.com/"><img src="/static/img/wb.png" alt=""></a><a
            href="" class="wx_hover"><img
            src="/static/img/dxy.png" alt="" class="codeleft"><img src="/static/img/wx.png" alt="" class="wxpicture"></a></p>
    <h3>联系我们&nbsp:000-000-000</h3>
</footer>
<script type="text/html" id="barDemo">
    <div class="site-demo-button" id="layerDemo" style="margin-bottom: 0;">
        <button type="button" lay-submit class="layui-btn layui-btn-danger" lay-event="addAre" lay-filter="addAre">
           确认收货
        </button>
    </div>
</script>
<script src="/static/layui/layui.js"></script>
<script src="/static/js/swiper.min.js"></script>
<script src="/static/js/mouseEvent.js"></script>
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<script>
    function GMTToStr(){
        var date = new Date();
        var Str=date.getFullYear() + '-' +
            (date.getMonth() + 1) + '-' +
            date.getDate() + ' ' +
            date.getHours() + ':' +
            date.getMinutes() + ':' +
            date.getSeconds()
        return Str
    }
    //拦截个人中心
    let judge_personal_href=document.getElementById("judge_personal_href");
    judge_personal_href.addEventListener("click",function (e) {
        e.preventDefault();
        if(!sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/login'); ?>")
        }else if(sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/personalCenter'); ?>")
        }
    });
    //拦截购物车
    let judge_shopcar_href=document.getElementById("judge_shopcar_href");
    judge_shopcar_href.addEventListener("click",function (e) {
        e.preventDefault();
        if(!sessionStorage.getItem("userid")){
            e.preventDefault();
            window.location.assign("<?php echo url('index/index/login'); ?>")
        }else if(sessionStorage.getItem("userid")){
            window.location.assign("<?php echo url('index/index/shopCar'); ?>")
        }
    });
    layui.use(['table','layer','element'], function(){
        var table = layui.table,
            element=layui.element,
        layer=layui.layer;
        element.on('tab(docDemoTabBrief)', function(data){
            table.reload('idTest', {
                url:'/api/order/makesure'
            });
        });
        table.on('tool(logmange)', function(obj) {
            if (obj.event === 'addAre') {
              layer.alert("确认收货吗?",function () {
                  let finishdate=GMTToStr();
                  obj.data.finishdate=finishdate;
                     axios.post("/api/order/makesh",{data:obj.data}).then(res=>{
                            if(res.data.code==200){
                                var index = layer.load();
                                setTimeout(function () {
                                    layer.close(index)
                                    layer.alert("收货成功!")
                                    obj.del();
                                },400)
                            }
                     })
              })
            }
        })
    });
</script>
</body>
</html>